-- ============================================
-- AI模拟面试平台 - 后台管理系统数据库表结构
-- 只包含：admin、job_position、article 表
-- ============================================

-- ============================================
-- 表1：管理员表 (admin)
-- 用途：存储后台管理员账号信息
-- ============================================
CREATE TABLE IF NOT EXISTS `admin` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `username` VARCHAR(50) NOT NULL COMMENT '用户名（登录账号）',
  `password` VARCHAR(255) NOT NULL COMMENT '密码（BCrypt加密）',
  `real_name` VARCHAR(50) COMMENT '真实姓名',
  `avatar` VARCHAR(255) COMMENT '头像URL',
  `phone` VARCHAR(20) COMMENT '手机号',
  `email` VARCHAR(100) COMMENT '邮箱',
  `status` VARCHAR(20) DEFAULT '已发布' COMMENT '状态：已发布、草稿',
  `last_login_ip` VARCHAR(50) COMMENT '最后登录IP',
  `last_login_time` DATETIME COMMENT '最后登录时间',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员表';

-- ============================================
-- 表3：岗位表 (job_position)
-- 用途：存储面试岗位信息
-- ============================================
CREATE TABLE IF NOT EXISTS `job_position` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `name` VARCHAR(100) NOT NULL COMMENT '岗位名称',
  `code` VARCHAR(50) COMMENT '岗位编码（唯一标识）',
  `category` VARCHAR(50) NOT NULL COMMENT '岗位分类（如：研发、产品、设计、运营）',
  `description` TEXT COMMENT '岗位描述',
  `requirements` TEXT COMMENT '岗位要求',
  `location` VARCHAR(100) COMMENT '工作地点',
  `status` VARCHAR(20) DEFAULT '已发布' COMMENT '状态：已发布、草稿',
  `publish_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_category` (`category`),
  KEY `idx_status` (`status`),
  KEY `idx_publish_time` (`publish_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='岗位表';

-- ============================================
-- 表5：课程/文章推荐表 (article)
-- 用途：存储后台发布的课程和文章推荐
-- ============================================
CREATE TABLE IF NOT EXISTS `article` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` VARCHAR(200) NOT NULL COMMENT '标题',
  `type` TINYINT NOT NULL COMMENT '类型：1-课程，2-文章',
  `cover_url` VARCHAR(500) COMMENT '封面图片URL',
  `link_url` VARCHAR(500) NOT NULL COMMENT '链接地址',
  `description` TEXT COMMENT '描述/简介',
  `author` VARCHAR(100) COMMENT '作者',
  `source` VARCHAR(100) COMMENT '来源',
  `sort` INT DEFAULT 0 COMMENT '排序（数字越小越靠前）',
  `view_count` INT DEFAULT 0 COMMENT '浏览次数',
  `status` TINYINT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
  `publish_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  KEY `idx_sort` (`sort`),
  KEY `idx_publish_time` (`publish_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课程/文章推荐表';

-- ============================================
-- 初始化数据
-- ============================================

-- 初始化管理员账号（密码：admin123，BCrypt加密）
INSERT INTO `admin` (`username`, `password`, `real_name`, `status`) VALUES
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '系统管理员', 1);

-- 初始化测试岗位数据
INSERT INTO `job_position` (`name`, `code`, `category`, `description`, `status`, `publish_time`) VALUES
('前端开发工程师', 'FE_DEV', '研发', '负责Web前端开发工作', 1, '2024-03-20 10:00:00'),
('后端开发工程师', 'BE_DEV', '研发', '负责服务端开发工作', 1, '2024-03-21 11:00:00'),
('高级产品经理', 'SR_PM', '产品', '负责产品规划和设计', 1, '2024-03-22 09:30:00'),
('UI设计师', 'UI_DESIGN', '设计', '负责界面设计工作', 1, '2024-03-23 14:00:00'),
('测试工程师', 'QA_ENG', '研发', '负责软件测试工作', 1, '2024-03-24 16:00:00');

-- 初始化测试课程/文章推荐数据
INSERT INTO `article` (`title`, `type`, `cover_url`, `link_url`, `description`, `author`, `source`, `sort`, `status`, `publish_time`) VALUES
('Java面试核心知识点精讲', 1, '/covers/java_interview.jpg', 'https://example.com/course/java-interview', '全面讲解Java面试高频考点，包括集合、多线程、JVM等', '李老师', '慕课网', 1, 1, '2024-03-25 10:00:00'),
('如何准备前端面试', 2, '/covers/frontend_article.jpg', 'https://example.com/article/frontend-interview', '从简历准备到技术面试，全方位指南', '王小明', '知乎', 2, 1, '2024-03-26 14:00:00'),
('Spring Boot项目实战', 1, '/covers/springboot.jpg', 'https://example.com/course/springboot', '从零开始搭建Spring Boot企业级项目', '张老师', '极客时间', 3, 1, '2024-03-27 09:30:00'),
('产品经理面试必备技能', 2, '/covers/pm_article.jpg', 'https://example.com/article/pm-interview', '产品思维、需求分析、项目管理全解析', '赵小姐', '人人都是产品经理', 4, 1, '2024-03-28 11:00:00'),
('算法面试通关指南', 1, '/covers/algorithm.jpg', 'https://example.com/course/algorithm', '数据结构与算法高频面试题精讲', '刘老师', '牛客网', 5, 1, '2024-03-29 16:00:00');
