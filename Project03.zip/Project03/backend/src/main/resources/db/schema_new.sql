-- ============================================
-- AI模拟面试平台 - 后台管理系统数据库设计
-- 根据前端界面重新设计
-- ============================================

-- 创建数据库
CREATE DATABASE IF NOT EXISTS interview_admin 
DEFAULT CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

USE interview_admin;

-- ============================================
-- 表1：管理员表 (admin)
-- 用途：存储后台管理员账号信息
-- 设计理由：
-- - 后台系统需要登录认证
-- - 记录最后登录时间和IP便于安全审计
-- ============================================
CREATE TABLE IF NOT EXISTS `admin` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `username` VARCHAR(50) NOT NULL COMMENT '用户名（登录账号）',
  `password` VARCHAR(255) NOT NULL COMMENT '密码（BCrypt加密）',
  `real_name` VARCHAR(50) COMMENT '真实姓名',
  `avatar` VARCHAR(255) COMMENT '头像URL',
  `phone` VARCHAR(20) COMMENT '手机号',
  `email` VARCHAR(100) COMMENT '邮箱',
  `status` VARCHAR(20) DEFAULT '已发布' COMMENT '状态：已发布、草稿',
  `last_login_ip` VARCHAR(50) COMMENT '最后登录IP',
  `last_login_time` DATETIME COMMENT '最后登录时间',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='管理员表';

-- ============================================
-- 表2：用户表 (user)
-- 用途：存储平台注册用户信息
-- 设计理由：
-- - 根据用户管理界面设计，包含头像、姓名等
-- - 统计字段：面试次数、平均分（避免重复查询）
-- - 支持账号禁用功能
-- - 注册时间用于排序和统计
-- ============================================
CREATE TABLE IF NOT EXISTS `user` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '用户ID',
  `username` VARCHAR(50) NOT NULL COMMENT '用户名（登录账号）',
  `password` VARCHAR(255) NOT NULL COMMENT '密码（BCrypt加密）',
  `real_name` VARCHAR(50) NOT NULL COMMENT '真实姓名',
  `avatar` VARCHAR(255) COMMENT '头像URL',
  `phone` VARCHAR(20) COMMENT '手机号',
  `email` VARCHAR(100) COMMENT '邮箱',
  `interview_count` INT DEFAULT 0 COMMENT '面试次数',
  `avg_score` DECIMAL(5,2) DEFAULT 0.00 COMMENT '平均分',
  `status` TINYINT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
  `register_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '注册时间',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_register_time` (`register_time`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='用户表';

-- ============================================
-- 表3：岗位表 (job_position)
-- 用途：存储面试岗位信息
-- 设计理由：
-- - 根据岗位管理界面设计，包含岗位名称、分类、状态等
-- - 分类字段用于筛选（前端有筛选下拉框）
-- - 状态字段：0-禁用，1-启用（前端有状态显示）
-- - 发布时间用于排序
-- ============================================
CREATE TABLE IF NOT EXISTS `job_position` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `name` VARCHAR(100) NOT NULL COMMENT '岗位名称',
  `code` VARCHAR(50) COMMENT '岗位编码（唯一标识）',
  `category` VARCHAR(50) NOT NULL COMMENT '岗位分类（如：研发、产品、设计、运营）',
  `description` TEXT COMMENT '岗位描述',
  `requirements` TEXT COMMENT '岗位要求',
  `location` VARCHAR(100) COMMENT '工作地点',
  `status` VARCHAR(20) DEFAULT '已发布' COMMENT '状态：已发布、草稿',
  `publish_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_category` (`category`),
  KEY `idx_status` (`status`),
  KEY `idx_publish_time` (`publish_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='岗位表';

-- ============================================
-- 表4：面试记录表 (interview_record)
-- 用途：存储面试记录信息
-- 设计理由：
-- - 根据面试记录管理界面设计
-- - 包含学生（用户）、面试岗位、面试时间、综合评分
-- - 综合评分DECIMAL类型，支持小数
-- - report_path字段存储报告路径（前端有查看报告按钮）
-- ============================================
CREATE TABLE IF NOT EXISTS `interview_record` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT '面试记录ID',
  `user_id` BIGINT NOT NULL COMMENT '用户ID',
  `user_name` VARCHAR(50) NOT NULL COMMENT '用户姓名（冗余字段，避免关联查询）',
  `user_avatar` VARCHAR(255) COMMENT '用户头像（冗余字段）',
  `position_id` BIGINT NOT NULL COMMENT '岗位ID',
  `position_name` VARCHAR(100) NOT NULL COMMENT '岗位名称（冗余字段，避免关联查询）',
  `interview_time` DATETIME COMMENT '面试时间',
  `score` DECIMAL(5,2) NOT NULL COMMENT '综合评分',
  `report_path` VARCHAR(500) COMMENT '面试报告路径',
  `start_time` DATETIME COMMENT '面试开始时间',
  `end_time` DATETIME COMMENT '面试结束时间',
  `duration` INT COMMENT '面试时长（秒）',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_position_id` (`position_id`),
  KEY `idx_interview_time` (`interview_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='面试记录表';

-- ============================================
-- 表5：课程/文章推荐表 (article)
-- 用途：存储后台发布的课程和文章推荐
-- 设计理由：
-- - 根据需求表格设计：发布/删除/改课程或者文章（链接地址）
-- - type字段区分是课程还是文章
-- - link_url字段存储链接地址
-- - sort字段用于排序（推荐顺序）
-- - 支持启用/禁用
-- ============================================
CREATE TABLE IF NOT EXISTS `article` (
  `id` BIGINT NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` VARCHAR(200) NOT NULL COMMENT '标题',
  `type` TINYINT NOT NULL COMMENT '类型：1-课程，2-文章',
  `cover_url` VARCHAR(500) COMMENT '封面图片URL',
  `link_url` VARCHAR(500) NOT NULL COMMENT '链接地址',
  `description` TEXT COMMENT '描述/简介',
  `author` VARCHAR(100) COMMENT '作者',
  `source` VARCHAR(100) COMMENT '来源',
  `sort` INT DEFAULT 0 COMMENT '排序（数字越小越靠前）',
  `view_count` INT DEFAULT 0 COMMENT '浏览次数',
  `status` TINYINT DEFAULT 1 COMMENT '状态：0-禁用，1-启用',
  `publish_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
  `create_time` DATETIME DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` TINYINT DEFAULT 0 COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  KEY `idx_sort` (`sort`),
  KEY `idx_publish_time` (`publish_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COMMENT='课程/文章推荐表';

-- ============================================
-- 初始化数据
-- ============================================

-- 初始化管理员账号（密码：admin123，BCrypt加密）
INSERT INTO `admin` (`username`, `password`, `real_name`, `status`) VALUES
('admin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '系统管理员', 1);

-- 初始化测试用户数据（与前端界面一致）
INSERT INTO `user` (`username`, `password`, `real_name`, `avatar`, `interview_count`, `avg_score`, `status`, `register_time`) VALUES
('zhangsan', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '张三', '/avatars/zhangsan.jpg', 8, 88.00, 1, '2024-03-01 10:00:00'),
('lisi', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '李四', '/avatars/lisi.jpg', 5, 75.00, 1, '2024-03-05 14:30:00'),
('wangwu', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '王五', '/avatars/wangwu.jpg', 12, 92.00, 1, '2024-03-10 09:15:00'),
('zhaoliu', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '赵六', '/avatars/zhaoliu.jpg', 3, 68.00, 1, '2024-03-15 16:45:00'),
('qianqi', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVKIUi', '钱七', '/avatars/qianqi.jpg', 1, 60.00, 1, '2024-03-20 11:20:00');

-- 初始化测试岗位数据（与前端界面一致）
INSERT INTO `job_position` (`name`, `code`, `category`, `description`, `status`, `publish_time`) VALUES
('前端开发工程师', 'FE_DEV', '研发', '负责Web前端开发工作', 1, '2024-03-20 10:00:00'),
('后端开发工程师', 'BE_DEV', '研发', '负责服务端开发工作', 1, '2024-03-21 11:00:00'),
('高级产品经理', 'SR_PM', '产品', '负责产品规划和设计', 1, '2024-03-22 09:30:00'),
('UI设计师', 'UI_DESIGN', '设计', '负责界面设计工作', 1, '2024-03-23 14:00:00'),
('测试工程师', 'QA_ENG', '研发', '负责软件测试工作', 1, '2024-03-24 16:00:00');

-- 初始化测试面试记录数据（与前端界面一致）
INSERT INTO `interview_record` (`user_id`, `user_name`, `user_avatar`, `position_id`, `position_name`, `interview_time`, `score`, `report_path`) VALUES
(1, '张三', '/avatars/zhangsan.jpg', 1, '前端开发工程师', '2024-03-28 14:30:00', 88.00, '/reports/zhangsan_20240328.pdf'),
(2, '李四', '/avatars/lisi.jpg', 2, '后端开发工程师', '2024-03-27 10:15:00', 92.00, '/reports/lisi_20240327.pdf'),
(3, '王五', '/avatars/wangwu.jpg', 3, '高级产品经理', '2024-03-26 16:45:00', 75.00, '/reports/wangwu_20240326.pdf'),
(4, '赵六', '/avatars/zhaoliu.jpg', 4, 'UI设计师', '2024-03-25 09:00:00', 82.00, '/reports/zhaoliu_20240325.pdf'),
(5, '钱七', '/avatars/qianqi.jpg', 5, '测试工程师', '2024-03-24 11:20:00', 68.00, '/reports/qianqi_20240324.pdf');

-- 初始化测试课程/文章推荐数据
INSERT INTO `article` (`title`, `type`, `cover_url`, `link_url`, `description`, `author`, `source`, `sort`, `status`, `publish_time`) VALUES
('Java面试核心知识点精讲', 1, '/covers/java_interview.jpg', 'https://example.com/course/java-interview', '全面讲解Java面试高频考点，包括集合、多线程、JVM等', '李老师', '慕课网', 1, 1, '2024-03-25 10:00:00'),
('如何准备前端面试', 2, '/covers/frontend_article.jpg', 'https://example.com/article/frontend-interview', '从简历准备到技术面试，全方位指南', '王小明', '知乎', 2, 1, '2024-03-26 14:00:00'),
('Spring Boot项目实战', 1, '/covers/springboot.jpg', 'https://example.com/course/springboot', '从零开始搭建Spring Boot企业级项目', '张老师', '极客时间', 3, 1, '2024-03-27 09:30:00'),
('产品经理面试必备技能', 2, '/covers/pm_article.jpg', 'https://example.com/article/pm-interview', '产品思维、需求分析、项目管理全解析', '赵小姐', '人人都是产品经理', 4, 1, '2024-03-28 11:00:00'),
('算法面试通关指南', 1, '/covers/algorithm.jpg', 'https://example.com/course/algorithm', '数据结构与算法高频面试题精讲', '刘老师', '牛客网', 5, 1, '2024-03-29 16:00:00');
