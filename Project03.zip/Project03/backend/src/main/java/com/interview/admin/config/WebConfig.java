package com.interview.admin.config;

import com.interview.admin.security.JwtAuthenticationInterceptor;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.CorsRegistry;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer {

    private final JwtAuthenticationInterceptor jwtAuthenticationInterceptor;

    public WebConfig(JwtAuthenticationInterceptor jwtAuthenticationInterceptor) {
        this.jwtAuthenticationInterceptor = jwtAuthenticationInterceptor;
    }

    // CORS 配置已移至 CorsFilter，避免重复配置

    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        registry.addInterceptor(jwtAuthenticationInterceptor)
                .order(1)
                .addPathPatterns("/**")
                .excludePathPatterns(
                        "/admin/auth/login",
                        "/admin/auth/**",
                        "/api/admin/auth/login",
                        "/api/admin/auth/**",
                        "/client/**",
                        "/api/client/**",
                        "/doc.html",
                        "/webjars/**",
                        "/v3/api-docs/**",
                        "/swagger-resources/**",
                        "/swagger-ui/**",
                        "/swagger-ui.html",
                        "/api/swagger-ui.html",
                        "/swagger-ui/**",
                        "/api/swagger-ui/**",
                        "/api/doc.html",
                        "/api/webjars/**",
                        "/api/v3/api-docs/**",
                        "/api/swagger-resources/**",
                        "/error",
                        "/h2-console/**",
                        "/api/h2-console/**",
                        "/favicon.ico"
                );
    }
}
