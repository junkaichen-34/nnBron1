package com.interview.admin.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@Schema(description = "面试记录视图对象")
public class InterviewRecordVO {

    @Schema(description = "记录ID", example = "1")
    private Long id;

    @Schema(description = "用户ID", example = "1")
    private Long userId;

    @Schema(description = "用户名", example = "user1")
    private String userName;

    @Schema(description = "用户头像")
    private String userAvatar;

    @Schema(description = "岗位ID", example = "1")
    private Long positionId;

    @Schema(description = "岗位名称", example = "Java开发工程师")
    private String positionName;

    @Schema(description = "面试时间")
    private LocalDateTime interviewTime;

    @Schema(description = "面试综合得分", example = "85.50")
    private BigDecimal totalScore;

    @Schema(description = "面试报告路径")
    private String reportPath;

    @Schema(description = "开始时间")
    private LocalDateTime startTime;

    @Schema(description = "结束时间")
    private LocalDateTime endTime;

    @Schema(description = "面试时长(分钟)", example = "45")
    private Integer duration;

    @Schema(description = "创建时间")
    private LocalDateTime createTime;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return userId;
    }

    public void setUserId(Long userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getUserAvatar() {
        return userAvatar;
    }

    public void setUserAvatar(String userAvatar) {
        this.userAvatar = userAvatar;
    }

    public Long getPositionId() {
        return positionId;
    }

    public void setPositionId(Long positionId) {
        this.positionId = positionId;
    }

    public String getPositionName() {
        return positionName;
    }

    public void setPositionName(String positionName) {
        this.positionName = positionName;
    }

    public LocalDateTime getInterviewTime() {
        return interviewTime;
    }

    public void setInterviewTime(LocalDateTime interviewTime) {
        this.interviewTime = interviewTime;
    }

    public BigDecimal getTotalScore() {
        return totalScore;
    }

    public void setTotalScore(BigDecimal totalScore) {
        this.totalScore = totalScore;
    }

    public String getReportPath() {
        return reportPath;
    }

    public void setReportPath(String reportPath) {
        this.reportPath = reportPath;
    }

    public LocalDateTime getStartTime() {
        return startTime;
    }

    public void setStartTime(LocalDateTime startTime) {
        this.startTime = startTime;
    }

    public LocalDateTime getEndTime() {
        return endTime;
    }

    public void setEndTime(LocalDateTime endTime) {
        this.endTime = endTime;
    }

    public Integer getDuration() {
        return duration;
    }

    public void setDuration(Integer duration) {
        this.duration = duration;
    }

    public LocalDateTime getCreateTime() {
        return createTime;
    }

    public void setCreateTime(LocalDateTime createTime) {
        this.createTime = createTime;
    }

    // 面试报告详情
    @Schema(description = "内容维度得分")
    private BigDecimal contentScore;

    @Schema(description = "表达维度得分")
    private BigDecimal expressionScore;

    @Schema(description = "全维度详细得分(JSON格式)")
    private String dimensionScoreDetail;

    @Schema(description = "面试亮点分析")
    private String interviewHighlights;

    @Schema(description = "面试不足分析")
    private String interviewShortcomings;

    @Schema(description = "改进建议")
    private String improvementSuggestions;

    @Schema(description = "优秀回答范例")
    private String excellentAnswerCase;

    @Schema(description = "管理员评语")
    private String adminComment;

    @Schema(description = "评语管理员ID")
    private Long adminId;

    @Schema(description = "评语时间")
    private LocalDateTime adminCommentTime;

    @Schema(description = "报告生成时间")
    private LocalDateTime reportGenerateTime;

    @Schema(description = "报告状态: 0-生成中, 1-已生成, 2-生成失败")
    private Integer reportStatus;

    public BigDecimal getContentScore() { return contentScore; }
    public void setContentScore(BigDecimal contentScore) { this.contentScore = contentScore; }

    public BigDecimal getExpressionScore() { return expressionScore; }
    public void setExpressionScore(BigDecimal expressionScore) { this.expressionScore = expressionScore; }

    public String getDimensionScoreDetail() { return dimensionScoreDetail; }
    public void setDimensionScoreDetail(String dimensionScoreDetail) { this.dimensionScoreDetail = dimensionScoreDetail; }

    public String getInterviewHighlights() { return interviewHighlights; }
    public void setInterviewHighlights(String interviewHighlights) { this.interviewHighlights = interviewHighlights; }

    public String getInterviewShortcomings() { return interviewShortcomings; }
    public void setInterviewShortcomings(String interviewShortcomings) { this.interviewShortcomings = interviewShortcomings; }

    public String getImprovementSuggestions() { return improvementSuggestions; }
    public void setImprovementSuggestions(String improvementSuggestions) { this.improvementSuggestions = improvementSuggestions; }

    public String getExcellentAnswerCase() { return excellentAnswerCase; }
    public void setExcellentAnswerCase(String excellentAnswerCase) { this.excellentAnswerCase = excellentAnswerCase; }

    public String getAdminComment() { return adminComment; }
    public void setAdminComment(String adminComment) { this.adminComment = adminComment; }

    public Long getAdminId() { return adminId; }
    public void setAdminId(Long adminId) { this.adminId = adminId; }

    public LocalDateTime getAdminCommentTime() { return adminCommentTime; }
    public void setAdminCommentTime(LocalDateTime adminCommentTime) { this.adminCommentTime = adminCommentTime; }

    public LocalDateTime getReportGenerateTime() { return reportGenerateTime; }
    public void setReportGenerateTime(LocalDateTime reportGenerateTime) { this.reportGenerateTime = reportGenerateTime; }

    public Integer getReportStatus() { return reportStatus; }
    public void setReportStatus(Integer reportStatus) { this.reportStatus = reportStatus; }
}
