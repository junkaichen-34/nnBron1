package com.interview.admin.enums;

public enum ArticleCategoryEnum {
    JAVA_BACKEND(0, "Java后端"),
    WEB_FRONTEND(1, "Web前端"),
    PYTHON(2, "Python"),
    GO_BACKEND(3, "Go后端"),
    GENERAL(4, "通用");

    private final Integer code;
    private final String desc;

    ArticleCategoryEnum(Integer code, String desc) {
        this.code = code;
        this.desc = desc;
    }

    public Integer getCode() {
        return code;
    }

    public String getDesc() {
        return desc;
    }

    public static String getDescByCode(Integer code) {
        if (code == null) {
            return null;
        }
        for (ArticleCategoryEnum item : values()) {
            if (item.getCode().equals(code)) {
                return item.getDesc();
            }
        }
        return null;
    }

    public static ArticleCategoryEnum getByCode(Integer code) {
        if (code == null) {
            return null;
        }
        for (ArticleCategoryEnum item : values()) {
            if (item.getCode().equals(code)) {
                return item;
            }
        }
        return null;
    }

    public static class CategoryInfo {
        private final Integer code;
        private final String desc;

        public CategoryInfo(Integer code, String desc) {
            this.code = code;
            this.desc = desc;
        }

        public Integer getCode() {
            return code;
        }

        public String getDesc() {
            return desc;
        }
    }
}
