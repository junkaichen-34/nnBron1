package com.interview.admin.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.entity.JobPosition;
import com.interview.admin.vo.JobPositionVO;
import java.util.List;

public interface JobPositionService {

    Page<JobPositionVO> getPositionList(Integer pageNum, Integer pageSize, String keyword, String status);

    Page<JobPositionVO> getPositionList(Integer pageNum, Integer pageSize, String keyword, String category, String status);

    JobPositionVO getPositionDetail(Long id);

    JobPosition addPosition(JobPosition position);

    JobPosition updatePosition(JobPosition position);

    void deletePosition(Long id);

    void updatePositionStatus(Long id, String status);

    List<JobPosition> getAllPositionsIncludingDeleted();
}
