package com.interview.admin.vo.response;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "登录响应数据")
public class LoginResponse {

    @Schema(description = "访问令牌", example = "eyJhbGciOiJIUzM4NCJ9...")
    private String accessToken;

    @Schema(description = "刷新令牌", example = "eyJhbGciOiJIUzM4NCJ9...")
    private String refreshToken;

    @Schema(description = "过期时间（秒）", example = "86400")
    private Long expiresIn;

    @Schema(description = "管理员信息")
    private AdminInfo adminInfo;

    @Schema(description = "登录响应中的管理员信息")
    public static class AdminInfo {
        @Schema(description = "管理员ID", example = "1")
        private Long id;

        @Schema(description = "用户名", example = "admin")
        private String username;

        @Schema(description = "真实姓名", example = "系统管理员")
        private String realName;

        @Schema(description = "手机号", example = "13800138000")
        private String phone;

        @Schema(description = "邮箱", example = "admin@example.com")
        private String email;

        @Schema(description = "头像URL")
        private String avatar;

        // Getters and Setters
        public Long getId() { return id; }
        public void setId(Long id) { this.id = id; }
        public String getUsername() { return username; }
        public void setUsername(String username) { this.username = username; }
        public String getRealName() { return realName; }
        public void setRealName(String realName) { this.realName = realName; }
        public String getPhone() { return phone; }
        public void setPhone(String phone) { this.phone = phone; }
        public String getEmail() { return email; }
        public void setEmail(String email) { this.email = email; }
        public String getAvatar() { return avatar; }
        public void setAvatar(String avatar) { this.avatar = avatar; }
    }

    // Getters and Setters
    public String getAccessToken() { return accessToken; }
    public void setAccessToken(String accessToken) { this.accessToken = accessToken; }
    public String getRefreshToken() { return refreshToken; }
    public void setRefreshToken(String refreshToken) { this.refreshToken = refreshToken; }
    public Long getExpiresIn() { return expiresIn; }
    public void setExpiresIn(Long expiresIn) { this.expiresIn = expiresIn; }
    public AdminInfo getAdminInfo() { return adminInfo; }
    public void setAdminInfo(AdminInfo adminInfo) { this.adminInfo = adminInfo; }
}
