package com.interview.admin.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.common.result.Result;
import com.interview.admin.enums.ArticleCategoryEnum;
import com.interview.admin.service.ArticleService;
import com.interview.admin.vo.ArticleVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Tag(name = "客户端-课程/文章", description = "客户端查看课程和文章推荐（只读）")
@RestController
@RequestMapping("/client/article")
public class ClientArticleController {

    private final ArticleService articleService;

    public ClientArticleController(ArticleService articleService) {
        this.articleService = articleService;
    }

    @Operation(summary = "获取推荐列表")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"current\":1,\"size\":10,\"total\":0,\"pages\":0,\"records\":[]}}")))
    @GetMapping("/list")
    public Result<Page<ArticleVO>> list(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer type,
            @RequestParam(required = false) Integer category) {
        Page<ArticleVO> page = articleService.getArticleList(pageNum, pageSize, keyword, type, null);
        return Result.success(page);
    }

    @Operation(summary = "获取推荐详情")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"title\":\"Java面试指南\",\"type\":2,\"coverUrl\":\"https://example.com/cover.jpg\",\"linkUrl\":\"https://example.com/article\",\"description\":\"完整的Java面试准备指南\",\"author\":\"John Doe\",\"source\":\"Tech Blog\",\"sort\":0,\"viewCount\":100,\"status\":1,\"publishTime\":\"2024-01-01T12:00:00\",\"createTime\":\"2024-01-01T12:00:00\"}}")))
    @GetMapping("/{id}")
    public Result<ArticleVO> detail(@PathVariable Long id) {
        ArticleVO vo = articleService.getArticleDetail(id);
        return Result.success(vo);
    }

    @Operation(summary = "获取文章分类列表")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":[{\"code\":0,\"desc\":\"Java后端\"},{\"code\":1,\"desc\":\"Web前端\"}]}")))
    @GetMapping("/categories")
    public Result<List<ArticleCategoryEnum.CategoryInfo>> categories() {
        List<ArticleCategoryEnum.CategoryInfo> list = Arrays.stream(ArticleCategoryEnum.values())
                .map(e -> new ArticleCategoryEnum.CategoryInfo(e.getCode(), e.getDesc()))
                .collect(Collectors.toList());
        return Result.success(list);
    }
}
