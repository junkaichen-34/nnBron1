package com.interview.admin.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.common.result.Result;
import com.interview.admin.service.UserService;
import com.interview.admin.vo.UserVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

@Tag(name = "用户管理", description = "用户列表、详情、状态管理")
@RestController
@RequestMapping("/admin/user")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @Operation(summary = "获取用户列表")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"current\":1,\"size\":10,\"total\":0,\"pages\":0,\"records\":[]}}")))
    @GetMapping("/list")
    public Result<Page<UserVO>> list(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer status) {
        Page<UserVO> page = userService.getUserList(pageNum, pageSize, keyword, status);
        return Result.success(page);
    }

    @Operation(summary = "获取用户详情")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"username\":\"user1\",\"realName\":\"张三\",\"avatar\":\"https://example.com/avatar.jpg\",\"phone\":\"13800138001\",\"email\":\"user1@example.com\",\"interviewCount\":5,\"avgScore\":85.50,\"status\":1,\"registerTime\":\"2024-01-01T12:00:00\",\"createTime\":\"2024-01-01T12:00:00\"}}")))
    @GetMapping("/{id}")
    public Result<UserVO> detail(@PathVariable Long id) {
        UserVO userVO = userService.getUserDetail(id);
        return Result.success(userVO);
    }

    @Operation(summary = "启用/禁用用户")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{}}")))
    @PutMapping("/{id}/status")
    public Result<Void> updateStatus(@PathVariable Long id, @RequestParam Integer status) {
        userService.updateUserStatus(id, status);
        return Result.success();
    }

    @Operation(summary = "删除用户")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{}}")))
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        userService.deleteUser(id);
        return Result.success();
    }
}
