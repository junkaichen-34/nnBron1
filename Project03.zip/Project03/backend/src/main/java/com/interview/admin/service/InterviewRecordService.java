package com.interview.admin.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.entity.InterviewRecord;
import com.interview.admin.vo.InterviewRecordVO;

public interface InterviewRecordService {
    Page<InterviewRecordVO> getRecordList(Integer pageNum, Integer pageSize, String keyword, Long userId, Long positionId);
    InterviewRecordVO getRecordDetail(Long id);
    String getReportPath(Long id);
    InterviewRecord createRecord(InterviewRecord record);
    InterviewRecord updateRecord(Long id, InterviewRecord record);
    void deleteRecord(Long id);
    void batchDeleteRecords(java.util.List<Long> ids);
}
