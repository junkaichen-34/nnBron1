package com.interview.admin.entity;

import com.baomidou.mybatisplus.annotation.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@TableName("interview_session")
public class InterviewRecord {

    @TableId(value = "session_id", type = IdType.AUTO)
    private Long id;

    private Long userId;

    private Long positionId;

    private Long resumeId;

    private String interviewMode;

    private Integer interviewStatus;

    private LocalDateTime startTime;

    private LocalDateTime endTime;

    private Integer interviewDuration;

    private BigDecimal totalScore;

    private String interviewEvaluation;

    private Integer hasReport;

    @TableField(fill = FieldFill.INSERT)
    private LocalDateTime createTime;

    @TableField(fill = FieldFill.INSERT_UPDATE)
    private LocalDateTime updateTime;

    @TableField("is_deleted")
    private Integer isDeleted;

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getPositionId() { return positionId; }
    public void setPositionId(Long positionId) { this.positionId = positionId; }
    public Long getResumeId() { return resumeId; }
    public void setResumeId(Long resumeId) { this.resumeId = resumeId; }
    public String getInterviewMode() { return interviewMode; }
    public void setInterviewMode(String interviewMode) { this.interviewMode = interviewMode; }
    public Integer getInterviewStatus() { return interviewStatus; }
    public void setInterviewStatus(Integer interviewStatus) { this.interviewStatus = interviewStatus; }
    public LocalDateTime getStartTime() { return startTime; }
    public void setStartTime(LocalDateTime startTime) { this.startTime = startTime; }
    public LocalDateTime getEndTime() { return endTime; }
    public void setEndTime(LocalDateTime endTime) { this.endTime = endTime; }
    public Integer getInterviewDuration() { return interviewDuration; }
    public void setInterviewDuration(Integer interviewDuration) { this.interviewDuration = interviewDuration; }
    public BigDecimal getTotalScore() { return totalScore; }
    public void setTotalScore(BigDecimal totalScore) { this.totalScore = totalScore; }
    public String getInterviewEvaluation() { return interviewEvaluation; }
    public void setInterviewEvaluation(String interviewEvaluation) { this.interviewEvaluation = interviewEvaluation; }
    public Integer getHasReport() { return hasReport; }
    public void setHasReport(Integer hasReport) { this.hasReport = hasReport; }
    public LocalDateTime getCreateTime() { return createTime; }
    public void setCreateTime(LocalDateTime createTime) { this.createTime = createTime; }
    public LocalDateTime getUpdateTime() { return updateTime; }
    public void setUpdateTime(LocalDateTime updateTime) { this.updateTime = updateTime; }
    public Integer getIsDeleted() { return isDeleted; }
    public void setIsDeleted(Integer isDeleted) { this.isDeleted = isDeleted; }
}
