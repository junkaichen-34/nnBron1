package com.interview.admin.controller;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.interview.admin.common.result.Result;
import com.interview.admin.entity.InterviewRecord;
import com.interview.admin.entity.JobPosition;
import com.interview.admin.entity.User;
import com.interview.admin.mapper.InterviewRecordMapper;
import com.interview.admin.mapper.JobPositionMapper;
import com.interview.admin.mapper.UserMapper;
import com.interview.admin.vo.DashboardStatsVO;
import com.interview.admin.vo.UserVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Tag(name = "数据统计", description = "仪表盘数据统计")
@RestController
@RequestMapping("/admin/dashboard")
public class DashboardController {

    private final UserMapper userMapper;
    private final JobPositionMapper jobPositionMapper;
    private final InterviewRecordMapper interviewRecordMapper;

    public DashboardController(UserMapper userMapper, JobPositionMapper jobPositionMapper, InterviewRecordMapper interviewRecordMapper) {
        this.userMapper = userMapper;
        this.jobPositionMapper = jobPositionMapper;
        this.interviewRecordMapper = interviewRecordMapper;
    }

    @Operation(summary = "获取仪表盘统计数据")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"totalUsers\":1000,\"activeUsers\":500,\"totalPositions\":50,\"totalQuestions\":200,\"todayInterviews\":10,\"totalInterviews\":100,\"thisMonthNewUsers\":50,\"recentUsers\":[]}}")))
    @GetMapping("/stats")
    public Result<DashboardStatsVO> getStats() {
        Long totalUsers = userMapper.selectCount(null);
        
        LambdaQueryWrapper<User> activeUserWrapper = new LambdaQueryWrapper<>();
        activeUserWrapper.eq(User::getStatus, 1);
        Long activeUsers = userMapper.selectCount(activeUserWrapper);

        Long totalPositions = jobPositionMapper.selectCount(null);
        
        Long totalQuestions = 0L;

        LocalDateTime todayStart = LocalDate.now().atStartOfDay();
        LocalDateTime todayEnd = todayStart.plusDays(1);
        LambdaQueryWrapper<InterviewRecord> todayInterviewWrapper = new LambdaQueryWrapper<>();
        todayInterviewWrapper.ge(InterviewRecord::getCreateTime, todayStart)
                .lt(InterviewRecord::getCreateTime, todayEnd);
        Long todayInterviews = interviewRecordMapper.selectCount(todayInterviewWrapper);

        Long totalInterviews = interviewRecordMapper.selectCount(null);

        LocalDateTime monthStart = LocalDate.now().withDayOfMonth(1).atStartOfDay();
        LambdaQueryWrapper<User> monthUserWrapper = new LambdaQueryWrapper<>();
        monthUserWrapper.ge(User::getCreateTime, monthStart);
        Long thisMonthNewUsers = userMapper.selectCount(monthUserWrapper);

        LambdaQueryWrapper<User> recentUserWrapper = new LambdaQueryWrapper<>();
        recentUserWrapper.orderByDesc(User::getCreateTime).last("LIMIT 5");
        List<User> recentUserList = userMapper.selectList(recentUserWrapper);
        List<UserVO> recentUsers = recentUserList.stream().map(this::convertToUserVO).toList();

        DashboardStatsVO stats = new DashboardStatsVO(
                totalUsers, activeUsers, totalPositions, totalQuestions,
                todayInterviews, totalInterviews, thisMonthNewUsers, recentUsers
        );
        return Result.success(stats);
    }

    private UserVO convertToUserVO(User user) {
        UserVO vo = new UserVO();
        BeanUtils.copyProperties(user, vo);
        return vo;
    }
}
