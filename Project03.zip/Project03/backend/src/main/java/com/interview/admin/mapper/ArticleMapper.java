package com.interview.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.interview.admin.entity.Article;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface ArticleMapper extends BaseMapper<Article> {
}
