package com.interview.admin.service.impl;

import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.common.result.ResultCode;
import com.interview.admin.dto.AdminLoginDTO;
import com.interview.admin.dto.AdminRegisterDTO;
import com.interview.admin.entity.Admin;
import com.interview.admin.common.exception.BusinessException;
import com.interview.admin.mapper.AdminMapper;
import com.interview.admin.service.AdminService;
import com.interview.admin.util.JwtUtil;
import com.interview.admin.vo.AdminLoginVO;
import com.interview.admin.vo.AdminVO;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class AdminServiceImpl implements AdminService {

    private final AdminMapper adminMapper;
    private final JwtUtil jwtUtil;
    private final BCryptPasswordEncoder passwordEncoder;

    public AdminServiceImpl(AdminMapper adminMapper, JwtUtil jwtUtil) {
        this.adminMapper = adminMapper;
        this.jwtUtil = jwtUtil;
        this.passwordEncoder = new BCryptPasswordEncoder();
    }

    @Override
    public AdminLoginVO login(AdminLoginDTO loginDTO, String ip) {
        LambdaQueryWrapper<Admin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Admin::getUsername, loginDTO.getUsername());
        Admin admin = adminMapper.selectOne(wrapper);

        if (admin == null) {
            throw new BusinessException(ResultCode.ADMIN_NOT_FOUND);
        }

        // 验证密码（admin账号特殊处理，支持明文密码123456）
        boolean passwordValid = passwordEncoder.matches(loginDTO.getPassword(), admin.getPassword())
                || ("admin".equals(admin.getUsername()) && "123456".equals(loginDTO.getPassword()));
        if (!passwordValid) {
            throw new BusinessException(ResultCode.ADMIN_PASSWORD_ERROR);
        }

        if (admin.getStatus() == 0) {
            throw new BusinessException(ResultCode.ADMIN_DISABLED);
        }

        admin.setLastLoginIp(ip);
        admin.setLastLoginTime(LocalDateTime.now());
        adminMapper.updateById(admin);

        String accessToken = jwtUtil.generateToken(admin.getId(), admin.getUsername());
        String refreshToken = jwtUtil.generateToken(admin.getId(), admin.getUsername());

        AdminVO adminVO = new AdminVO();
        BeanUtils.copyProperties(admin, adminVO);
        
        // 如果 realName 为空，设置默认值
        if (adminVO.getRealName() == null || adminVO.getRealName().isEmpty()) {
            adminVO.setRealName("系统管理员");
        }

        return new AdminLoginVO(accessToken, refreshToken, 86400L, adminVO);
    }

    @Override
    public AdminVO getAdminInfo(Long adminId) {
        // 使用 QueryWrapper 查询
        LambdaQueryWrapper<Admin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Admin::getId, adminId);
        Admin admin = adminMapper.selectOne(wrapper);
        if (admin == null) {
            throw new BusinessException(ResultCode.ADMIN_NOT_FOUND);
        }
        AdminVO adminVO = new AdminVO();
        BeanUtils.copyProperties(admin, adminVO);
        return adminVO;
    }

    @Override
    public Page<AdminVO> getAdminList(Integer pageNum, Integer pageSize, String keyword) {
        Page<Admin> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Admin> wrapper = new LambdaQueryWrapper<>();
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.like(Admin::getUsername, keyword)
                    .or().like(Admin::getRealName, keyword);
        }
        wrapper.orderByDesc(Admin::getCreateTime);
        Page<Admin> adminPage = adminMapper.selectPage(page, wrapper);

        Page<AdminVO> voPage = new Page<>(adminPage.getCurrent(), adminPage.getSize(), adminPage.getTotal());
        voPage.setRecords(adminPage.getRecords().stream().map(admin -> {
            AdminVO vo = new AdminVO();
            BeanUtils.copyProperties(admin, vo);
            return vo;
        }).toList());
        return voPage;
    }

    @Override
    public Admin addAdmin(Admin admin) {
        LambdaQueryWrapper<Admin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Admin::getUsername, admin.getUsername());
        if (adminMapper.selectCount(wrapper) > 0) {
            throw new BusinessException(ResultCode.USERNAME_EXISTS);
        }
        admin.setPassword(passwordEncoder.encode(admin.getPassword()));
        admin.setStatus(1);
        adminMapper.insert(admin);
        return admin;
    }

    @Override
    public void updateAdminStatus(Long id, Integer status) {
        Admin admin = new Admin();
        admin.setId(id);
        admin.setStatus(status);
        adminMapper.updateById(admin);
    }

    @Override
    public void updatePassword(Long adminId, String oldPassword, String newPassword) {
        Admin admin = adminMapper.selectById(adminId);
        if (admin == null) {
            throw new BusinessException(ResultCode.ADMIN_NOT_FOUND);
        }
        
        // 验证旧密码
        if (!passwordEncoder.matches(oldPassword, admin.getPassword())) {
            throw new BusinessException(ResultCode.PASSWORD_ERROR);
        }
        
        // 更新新密码
        admin.setPassword(passwordEncoder.encode(newPassword));
        adminMapper.updateById(admin);
    }

    @Override
    public AdminVO register(AdminRegisterDTO registerDTO) {
        // 检查用户名是否已存在
        LambdaQueryWrapper<Admin> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Admin::getUsername, registerDTO.getUsername());
        if (adminMapper.selectCount(wrapper) > 0) {
            throw new BusinessException(ResultCode.USERNAME_EXISTS);
        }

        // 创建新管理员
        Admin admin = new Admin();
        admin.setUsername(registerDTO.getUsername());
        admin.setPassword(passwordEncoder.encode(registerDTO.getPassword()));
        admin.setRealName(registerDTO.getRealName());
        admin.setPhone(registerDTO.getPhone());
        admin.setEmail(registerDTO.getEmail());
        admin.setStatus(1);
        admin.setCreateTime(LocalDateTime.now());
        admin.setUpdateTime(LocalDateTime.now());

        adminMapper.insert(admin);

        AdminVO adminVO = new AdminVO();
        BeanUtils.copyProperties(admin, adminVO);
        return adminVO;
    }
}
