package com.interview.admin.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.common.exception.BusinessException;
import com.interview.admin.common.result.ResultCode;
import com.interview.admin.entity.InterviewRecord;
import com.interview.admin.entity.InterviewReport;
import com.interview.admin.entity.JobPosition;
import com.interview.admin.entity.User;
import com.interview.admin.mapper.InterviewRecordMapper;
import com.interview.admin.mapper.InterviewReportMapper;
import com.interview.admin.mapper.JobPositionMapper;
import com.interview.admin.mapper.UserMapper;
import com.interview.admin.service.InterviewRecordService;
import com.interview.admin.vo.InterviewRecordVO;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class InterviewRecordServiceImpl implements InterviewRecordService {

    @Autowired
    private InterviewRecordMapper interviewRecordMapper;

    @Autowired
    private InterviewReportMapper interviewReportMapper;

    @Autowired
    private UserMapper userMapper;

    @Autowired
    private JobPositionMapper jobPositionMapper;

    @Override
    public Page<InterviewRecordVO> getRecordList(Integer pageNum, Integer pageSize, String keyword, Long userId, Long positionId) {
        Page<InterviewRecord> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<InterviewRecord> wrapper = new LambdaQueryWrapper<>();
        
        // 过滤已删除的记录
        wrapper.eq(InterviewRecord::getIsDeleted, 0);
        
        if (userId != null) {
            wrapper.eq(InterviewRecord::getUserId, userId);
        }
        if (positionId != null) {
            wrapper.eq(InterviewRecord::getPositionId, positionId);
        }
        
        wrapper.orderByDesc(InterviewRecord::getCreateTime);
        Page<InterviewRecord> recordPage = interviewRecordMapper.selectPage(page, wrapper);
        
        Page<InterviewRecordVO> voPage = new Page<>(recordPage.getCurrent(), recordPage.getSize(), recordPage.getTotal());
        voPage.setRecords(recordPage.getRecords().stream().map(this::convertToVO).toList());
        return voPage;
    }

    @Override
    public InterviewRecordVO getRecordDetail(Long id) {
        InterviewRecord record = interviewRecordMapper.selectById(id);
        if (record == null) {
            throw new BusinessException(ResultCode.INTERVIEW_RECORD_NOT_FOUND);
        }
        InterviewRecordVO vo = convertToVO(record);
        
        // 查询关联的报告详情
        InterviewReport report = interviewReportMapper.selectBySessionId(id);
        if (report != null) {
            vo.setContentScore(report.getContentScore());
            vo.setExpressionScore(report.getExpressionScore());
            vo.setDimensionScoreDetail(report.getDimensionScoreDetail());
            vo.setInterviewHighlights(report.getInterviewHighlights());
            vo.setInterviewShortcomings(report.getInterviewShortcomings());
            vo.setImprovementSuggestions(report.getImprovementSuggestions());
            vo.setExcellentAnswerCase(report.getExcellentAnswerCase());
            vo.setAdminComment(report.getAdminComment());
            vo.setAdminId(report.getAdminId());
            vo.setAdminCommentTime(report.getAdminCommentTime());
            vo.setReportGenerateTime(report.getReportGenerateTime());
            vo.setReportStatus(report.getReportStatus());
        }
        
        return vo;
    }

    @Override
    public String getReportPath(Long id) {
        InterviewRecord record = interviewRecordMapper.selectById(id);
        if (record == null) {
            throw new BusinessException(ResultCode.INTERVIEW_RECORD_NOT_FOUND);
        }
        
        InterviewReport report = interviewReportMapper.selectBySessionId(id);
        if (report != null && report.getReportStatus() != null && report.getReportStatus() == 1) {
            return "/reports/" + report.getReportId() + ".pdf";
        }
        return null;
    }

    @Override
    public InterviewRecord createRecord(InterviewRecord record) {
        interviewRecordMapper.insert(record);
        return record;
    }

    @Override
    public InterviewRecord updateRecord(Long id, InterviewRecord record) {
        InterviewRecord existing = interviewRecordMapper.selectById(id);
        if (existing == null) {
            throw new BusinessException(ResultCode.INTERVIEW_RECORD_NOT_FOUND);
        }
        
        // 只更新非null字段，避免覆盖原有数据
        if (record.getUserId() != null) {
            existing.setUserId(record.getUserId());
        }
        if (record.getPositionId() != null) {
            existing.setPositionId(record.getPositionId());
        }
        if (record.getResumeId() != null) {
            existing.setResumeId(record.getResumeId());
        }
        if (record.getInterviewMode() != null) {
            existing.setInterviewMode(record.getInterviewMode());
        }
        if (record.getInterviewStatus() != null) {
            existing.setInterviewStatus(record.getInterviewStatus());
        }
        if (record.getStartTime() != null) {
            existing.setStartTime(record.getStartTime());
        }
        if (record.getEndTime() != null) {
            existing.setEndTime(record.getEndTime());
        }
        if (record.getInterviewDuration() != null) {
            existing.setInterviewDuration(record.getInterviewDuration());
        }
        if (record.getTotalScore() != null) {
            existing.setTotalScore(record.getTotalScore());
        }
        if (record.getInterviewEvaluation() != null) {
            existing.setInterviewEvaluation(record.getInterviewEvaluation());
        }
        
        interviewRecordMapper.updateById(existing);
        return interviewRecordMapper.selectById(id);
    }

    @Override
    public void deleteRecord(Long id) {
        InterviewRecord existing = interviewRecordMapper.selectById(id);
        if (existing == null) {
            throw new BusinessException(ResultCode.INTERVIEW_RECORD_NOT_FOUND);
        }
        // 逻辑删除
        existing.setIsDeleted(1);
        interviewRecordMapper.updateById(existing);
    }

    @Override
    public void batchDeleteRecords(java.util.List<Long> ids) {
        if (ids != null && !ids.isEmpty()) {
            for (Long id : ids) {
                deleteRecord(id);
            }
        }
    }

    private InterviewRecordVO convertToVO(InterviewRecord record) {
        InterviewRecordVO vo = new InterviewRecordVO();
        BeanUtils.copyProperties(record, vo);
        
        // 查询用户名
        if (record.getUserId() != null) {
            User user = userMapper.selectById(record.getUserId());
            if (user != null) {
                vo.setUserName(user.getUsername());
                vo.setUserAvatar(user.getAvatar());
            }
        }
        
        // 查询岗位名称
        if (record.getPositionId() != null) {
            JobPosition position = jobPositionMapper.selectById(record.getPositionId());
            if (position != null) {
                vo.setPositionName(position.getName());
            }
        }
        
        return vo;
    }
}
