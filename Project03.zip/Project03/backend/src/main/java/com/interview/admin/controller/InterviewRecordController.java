package com.interview.admin.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.common.result.Result;
import com.interview.admin.entity.InterviewRecord;
import com.interview.admin.service.InterviewRecordService;
import com.interview.admin.vo.InterviewRecordVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

@Tag(name = "面试记录管理", description = "面试记录列表、详情、查看报告")
@RestController
@RequestMapping({"/admin/interview-record", "/admin/interviews"})
public class InterviewRecordController {

    private final InterviewRecordService interviewRecordService;

    public InterviewRecordController(InterviewRecordService interviewRecordService) {
        this.interviewRecordService = interviewRecordService;
    }

    @Operation(summary = "获取面试记录列表")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"current\":1,\"size\":10,\"total\":0,\"pages\":0,\"records\":[]}}")))
    @GetMapping("/list")
    public Result<Page<InterviewRecordVO>> list(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) Long positionId) {
        Page<InterviewRecordVO> page = interviewRecordService.getRecordList(pageNum, pageSize, keyword, userId, positionId);
        return Result.success(page);
    }

    @Operation(summary = "获取面试记录详情")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"userId\":1,\"userName\":\"user1\",\"userAvatar\":\"https://example.com/avatar.jpg\",\"positionId\":1,\"positionName\":\"Java开发工程师\",\"interviewTime\":\"2024-01-01T12:00:00\",\"score\":85.50,\"status\":2,\"reportPath\":\"/reports/1.pdf\",\"startTime\":\"2024-01-01T12:00:00\",\"endTime\":\"2024-01-01T12:45:00\",\"duration\":45,\"createTime\":\"2024-01-01T12:00:00\"}}")))
    @GetMapping("/{id}")
    public Result<InterviewRecordVO> detail(@PathVariable Long id) {
        InterviewRecordVO vo = interviewRecordService.getRecordDetail(id);
        return Result.success(vo);
    }

    @Operation(summary = "查看面试报告")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":\"/reports/1.pdf\"}")))
    @GetMapping("/{id}/report")
    public Result<String> getReport(@PathVariable Long id) {
        String reportPath = interviewRecordService.getReportPath(id);
        return Result.success(reportPath);
    }

    @Operation(summary = "创建面试记录")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"userId\":1,\"userName\":\"user1\",\"positionId\":1,\"positionName\":\"Java开发工程师\",\"interviewTime\":\"2024-01-01T12:00:00\",\"status\":0,\"createTime\":\"2024-01-01T12:00:00\"}}")))
    @PostMapping
    public Result<InterviewRecord> create(@RequestBody InterviewRecord record) {
        InterviewRecord result = interviewRecordService.createRecord(record);
        return Result.success(result);
    }

    @Operation(summary = "更新面试记录")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"userId\":1,\"userName\":\"user1\",\"positionId\":1,\"positionName\":\"Java开发工程师\",\"interviewTime\":\"2024-01-01T12:00:00\",\"status\":0,\"createTime\":\"2024-01-01T12:00:00\"}}")))
    @PutMapping("/update/{id}")
    public Result<InterviewRecord> update(@PathVariable Long id, @RequestBody InterviewRecord record) {
        InterviewRecord result = interviewRecordService.updateRecord(id, record);
        return Result.success(result);
    }

    @Operation(summary = "删除面试记录")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":null}")))
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        interviewRecordService.deleteRecord(id);
        return Result.success();
    }

    @Operation(summary = "批量删除面试记录")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":null}")))
    @DeleteMapping("/batch")
    public Result<Void> batchDelete(@RequestBody java.util.List<Long> ids) {
        interviewRecordService.batchDeleteRecords(ids);
        return Result.success();
    }
}
