package com.interview.admin.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.entity.Article;
import com.interview.admin.vo.ArticleVO;

public interface ArticleService {
    Page<ArticleVO> getArticleList(Integer pageNum, Integer pageSize, String keyword, Integer type, Integer status);
    ArticleVO getArticleDetail(Long id);
    Article addArticle(Article article);
    Article updateArticle(Article article);
    void updateArticleStatus(Long id, Integer status);
    void deleteArticle(Long id);
}
