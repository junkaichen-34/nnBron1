package com.interview.admin.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.common.result.Result;
import com.interview.admin.entity.Article;
import com.interview.admin.enums.ArticleCategoryEnum;
import com.interview.admin.service.ArticleService;
import com.interview.admin.vo.ArticleVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Tag(name = "课程/文章推荐", description = "课程和文章推荐管理")
@RestController
@RequestMapping("/admin/article")
public class ArticleController {

    private final ArticleService articleService;

    public ArticleController(ArticleService articleService) {
        this.articleService = articleService;
    }

    @Operation(summary = "获取推荐列表")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"current\":1,\"size\":10,\"total\":0,\"pages\":0,\"records\":[]}}")))
    @GetMapping("/list")
    public Result<Page<ArticleVO>> list(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) Integer type,
            @RequestParam(required = false) Integer status) {
        Page<ArticleVO> page = articleService.getArticleList(pageNum, pageSize, keyword, type, status);
        return Result.success(page);
    }

    @Operation(summary = "获取推荐详情")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"title\":\"Java面试指南\",\"type\":2,\"coverUrl\":\"https://example.com/cover.jpg\",\"linkUrl\":\"https://example.com/article\",\"description\":\"完整的Java面试准备指南\",\"author\":\"John Doe\",\"source\":\"Tech Blog\",\"sort\":0,\"viewCount\":100,\"status\":1,\"publishTime\":\"2024-01-01T12:00:00\",\"createTime\":\"2024-01-01T12:00:00\"}}")))
    @GetMapping("/{id}")
    public Result<ArticleVO> detail(@PathVariable Long id) {
        ArticleVO vo = articleService.getArticleDetail(id);
        return Result.success(vo);
    }

    @Operation(summary = "新增推荐")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"title\":\"Java面试指南\",\"type\":2,\"status\":1}}")))
    @PostMapping
    public Result<Article> add(@RequestBody Article article) {
        Article result = articleService.addArticle(article);
        return Result.success(result);
    }

    @Operation(summary = "更新推荐")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"title\":\"Java面试指南\",\"type\":2,\"status\":1}}")))
    @PutMapping
    public Result<Article> update(@RequestBody Article article) {
        Article result = articleService.updateArticle(article);
        return Result.success(result);
    }

    @Operation(summary = "启用/禁用推荐")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{}}")))
    @PutMapping("/{id}/status")
    public Result<Void> updateStatus(@PathVariable Long id, @RequestParam Integer status) {
        articleService.updateArticleStatus(id, status);
        return Result.success();
    }

    @Operation(summary = "删除推荐")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{}}")))
    @DeleteMapping("/{id}")
    public Result<Void> delete(@PathVariable Long id) {
        articleService.deleteArticle(id);
        return Result.success();
    }

    @Operation(summary = "获取文章分类列表")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":[{\"code\":0,\"desc\":\"Java后端\"},{\"code\":1,\"desc\":\"Web前端\"},{\"code\":2,\"desc\":\"Python\"},{\"code\":3,\"desc\":\"Go后端\"},{\"code\":4,\"desc\":\"通用\"}]}")))
    @GetMapping("/categories")
    public Result<List<Map<String, Object>>> getCategories() {
        List<Map<String, Object>> categories = Arrays.stream(ArticleCategoryEnum.values())
                .map(item -> {
                    Map<String, Object> map = new HashMap<>();
                    map.put("code", item.getCode());
                    map.put("desc", item.getDesc());
                    return map;
                })
                .collect(Collectors.toList());
        return Result.success(categories);
    }
}
