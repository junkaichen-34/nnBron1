package com.interview.admin.entity;

import com.baomidou.mybatisplus.annotation.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;

@TableName("interview_report")
public class InterviewReport {

    @TableId(value = "report_id", type = IdType.AUTO)
    private Long reportId;

    @TableField("session_id")
    private Long sessionId;

    @TableField("user_id")
    private Long userId;

    @TableField("position_id")
    private Long positionId;

    @TableField("total_score")
    private BigDecimal totalScore;

    @TableField("content_score")
    private BigDecimal contentScore;

    @TableField("expression_score")
    private BigDecimal expressionScore;

    @TableField("dimension_score_detail")
    private String dimensionScoreDetail;

    @TableField("interview_highlights")
    private String interviewHighlights;

    @TableField("interview_shortcomings")
    private String interviewShortcomings;

    @TableField("improvement_suggestions")
    private String improvementSuggestions;

    @TableField("excellent_answer_case")
    private String excellentAnswerCase;

    @TableField("admin_comment")
    private String adminComment;

    @TableField("admin_id")
    private Long adminId;

    @TableField("admin_comment_time")
    private LocalDateTime adminCommentTime;

    @TableField("report_generate_time")
    private LocalDateTime reportGenerateTime;

    @TableField("report_status")
    private Integer reportStatus;

    @TableField("update_time")
    private LocalDateTime updateTime;

    @TableField("is_deleted")
    private Integer isDeleted;

    public Long getReportId() { return reportId; }
    public void setReportId(Long reportId) { this.reportId = reportId; }

    public Long getSessionId() { return sessionId; }
    public void setSessionId(Long sessionId) { this.sessionId = sessionId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getPositionId() { return positionId; }
    public void setPositionId(Long positionId) { this.positionId = positionId; }

    public BigDecimal getTotalScore() { return totalScore; }
    public void setTotalScore(BigDecimal totalScore) { this.totalScore = totalScore; }

    public BigDecimal getContentScore() { return contentScore; }
    public void setContentScore(BigDecimal contentScore) { this.contentScore = contentScore; }

    public BigDecimal getExpressionScore() { return expressionScore; }
    public void setExpressionScore(BigDecimal expressionScore) { this.expressionScore = expressionScore; }

    public String getDimensionScoreDetail() { return dimensionScoreDetail; }
    public void setDimensionScoreDetail(String dimensionScoreDetail) { this.dimensionScoreDetail = dimensionScoreDetail; }

    public String getInterviewHighlights() { return interviewHighlights; }
    public void setInterviewHighlights(String interviewHighlights) { this.interviewHighlights = interviewHighlights; }

    public String getInterviewShortcomings() { return interviewShortcomings; }
    public void setInterviewShortcomings(String interviewShortcomings) { this.interviewShortcomings = interviewShortcomings; }

    public String getImprovementSuggestions() { return improvementSuggestions; }
    public void setImprovementSuggestions(String improvementSuggestions) { this.improvementSuggestions = improvementSuggestions; }

    public String getExcellentAnswerCase() { return excellentAnswerCase; }
    public void setExcellentAnswerCase(String excellentAnswerCase) { this.excellentAnswerCase = excellentAnswerCase; }

    public String getAdminComment() { return adminComment; }
    public void setAdminComment(String adminComment) { this.adminComment = adminComment; }

    public Long getAdminId() { return adminId; }
    public void setAdminId(Long adminId) { this.adminId = adminId; }

    public LocalDateTime getAdminCommentTime() { return adminCommentTime; }
    public void setAdminCommentTime(LocalDateTime adminCommentTime) { this.adminCommentTime = adminCommentTime; }

    public LocalDateTime getReportGenerateTime() { return reportGenerateTime; }
    public void setReportGenerateTime(LocalDateTime reportGenerateTime) { this.reportGenerateTime = reportGenerateTime; }

    public Integer getReportStatus() { return reportStatus; }
    public void setReportStatus(Integer reportStatus) { this.reportStatus = reportStatus; }

    public LocalDateTime getUpdateTime() { return updateTime; }
    public void setUpdateTime(LocalDateTime updateTime) { this.updateTime = updateTime; }

    public Integer getIsDeleted() { return isDeleted; }
    public void setIsDeleted(Integer isDeleted) { this.isDeleted = isDeleted; }
}
