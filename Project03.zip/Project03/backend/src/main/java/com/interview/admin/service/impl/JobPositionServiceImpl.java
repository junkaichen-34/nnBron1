package com.interview.admin.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.common.result.ResultCode;
import com.interview.admin.common.exception.BusinessException;
import com.interview.admin.entity.JobPosition;
import com.interview.admin.mapper.JobPositionMapper;
import com.interview.admin.service.JobPositionService;
import com.interview.admin.vo.JobPositionVO;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class JobPositionServiceImpl implements JobPositionService {

    private final JobPositionMapper jobPositionMapper;

    public JobPositionServiceImpl(JobPositionMapper jobPositionMapper) {
        this.jobPositionMapper = jobPositionMapper;
    }

    @Override
    public Page<JobPositionVO> getPositionList(Integer pageNum, Integer pageSize, String keyword, String status) {
        return getPositionList(pageNum, pageSize, keyword, null, status);
    }

    @Override
    public Page<JobPositionVO> getPositionList(Integer pageNum, Integer pageSize, String keyword, String category, String status) {
        Page<JobPosition> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<JobPosition> wrapper = new LambdaQueryWrapper<>();
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.like(JobPosition::getName, keyword)
                    .or().like(JobPosition::getCode, keyword);
        }
        if (category != null && !category.isEmpty()) {
            wrapper.eq(JobPosition::getCategory, category);
        }
        if (status != null) {
            wrapper.eq(JobPosition::getStatus, status);
        }
        wrapper.orderByDesc(JobPosition::getCreateTime);
        Page<JobPosition> positionPage = jobPositionMapper.selectPage(page, wrapper);

        Page<JobPositionVO> voPage = new Page<>(positionPage.getCurrent(), positionPage.getSize(), positionPage.getTotal());
        voPage.setRecords(positionPage.getRecords().stream().map(position -> {
            JobPositionVO vo = new JobPositionVO();
            BeanUtils.copyProperties(position, vo);
            return vo;
        }).toList());
        return voPage;
    }

    @Override
    public JobPositionVO getPositionDetail(Long id) {
        JobPosition position = jobPositionMapper.selectById(id);
        if (position == null) {
            throw new BusinessException(ResultCode.POSITION_NOT_FOUND);
        }
        JobPositionVO vo = new JobPositionVO();
        BeanUtils.copyProperties(position, vo);
        return vo;
    }

    @Override
    public JobPosition addPosition(JobPosition position) {
        // 校验编码唯一性（code不为空时校验）
        if (position.getCode() != null && !position.getCode().isEmpty()) {
            LambdaQueryWrapper<JobPosition> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(JobPosition::getCode, position.getCode());
            if (jobPositionMapper.selectCount(wrapper) > 0) {
                throw new BusinessException(ResultCode.POSITION_CODE_EXISTS);
            }
        }
        // 设置默认值
        if (position.getStatus() == null || position.getStatus().isEmpty()) {
            position.setStatus("已发布");
        }
        jobPositionMapper.insert(position);
        return jobPositionMapper.selectById(position.getId());
    }

    @Override
    public JobPosition updatePosition(JobPosition position) {
        // 校验岗位是否存在
        JobPosition exist = jobPositionMapper.selectById(position.getId());
        if (exist == null) {
            throw new BusinessException(ResultCode.POSITION_NOT_FOUND);
        }
        // 如果修改了编码，校验新编码是否已存在
        if (position.getCode() != null && !position.getCode().equals(exist.getCode())) {
            LambdaQueryWrapper<JobPosition> wrapper = new LambdaQueryWrapper<>();
            wrapper.eq(JobPosition::getCode, position.getCode());
            if (jobPositionMapper.selectCount(wrapper) > 0) {
                throw new BusinessException(ResultCode.POSITION_CODE_EXISTS);
            }
        }
        jobPositionMapper.updateById(position);
        return jobPositionMapper.selectById(position.getId());
    }

    @Override
    public void deletePosition(Long id) {
        JobPosition position = jobPositionMapper.selectById(id);
        if (position == null) {
            throw new BusinessException(ResultCode.POSITION_NOT_FOUND);
        }
        jobPositionMapper.deleteById(id);
    }

    @Override
    public void updatePositionStatus(Long id, String status) {
        JobPosition position = jobPositionMapper.selectById(id);
        if (position == null) {
            throw new BusinessException(ResultCode.POSITION_NOT_FOUND);
        }
        position.setStatus(status);
        jobPositionMapper.updateById(position);
    }

    @Override
    public List<JobPosition> getAllPositionsIncludingDeleted() {
        return jobPositionMapper.selectList(null);
    }
}
