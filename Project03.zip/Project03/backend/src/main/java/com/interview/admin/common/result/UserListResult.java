package com.interview.admin.common.result;

import com.interview.admin.vo.UserVO;
import io.swagger.v3.oas.annotations.media.Schema;

import java.util.List;

@Schema(description = "用户列表响应")
public class UserListResult {

    @Schema(description = "响应码", example = "200")
    private Integer code;

    @Schema(description = "响应消息", example = "操作成功")
    private String message;

    @Schema(description = "响应数据")
    private UserListData data;

    public static class UserListData {
        @Schema(description = "当前页", example = "1")
        private Long current;

        @Schema(description = "每页大小", example = "10")
        private Long size;

        @Schema(description = "总记录数", example = "100")
        private Long total;

        @Schema(description = "总页数", example = "10")
        private Long pages;

        @Schema(description = "用户列表")
        private List<UserVO> records;

        // Getters and Setters
        public Long getCurrent() { return current; }
        public void setCurrent(Long current) { this.current = current; }
        public Long getSize() { return size; }
        public void setSize(Long size) { this.size = size; }
        public Long getTotal() { return total; }
        public void setTotal(Long total) { this.total = total; }
        public Long getPages() { return pages; }
        public void setPages(Long pages) { this.pages = pages; }
        public List<UserVO> getRecords() { return records; }
        public void setRecords(List<UserVO> records) { this.records = records; }
    }

    // Getters and Setters
    public Integer getCode() { return code; }
    public void setCode(Integer code) { this.code = code; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public UserListData getData() { return data; }
    public void setData(UserListData data) { this.data = data; }
}
