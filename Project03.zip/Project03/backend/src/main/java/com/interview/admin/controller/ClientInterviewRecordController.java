package com.interview.admin.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.common.result.Result;
import com.interview.admin.service.InterviewRecordService;
import com.interview.admin.vo.InterviewRecordVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

@Tag(name = "客户端-面试记录", description = "客户端查看面试记录（只读）")
@RestController
@RequestMapping("/client/interview-record")
public class ClientInterviewRecordController {

    private final InterviewRecordService interviewRecordService;

    public ClientInterviewRecordController(InterviewRecordService interviewRecordService) {
        this.interviewRecordService = interviewRecordService;
    }

    @Operation(summary = "获取面试记录列表")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"current\":1,\"size\":10,\"total\":0,\"pages\":0,\"records\":[]}}")))
    @GetMapping("/list")
    public Result<Page<InterviewRecordVO>> list(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) Long userId,
            @RequestParam(required = false) Long positionId) {
        Page<InterviewRecordVO> page = interviewRecordService.getRecordList(pageNum, pageSize, null, userId, positionId);
        return Result.success(page);
    }

    @Operation(summary = "获取面试记录详情")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"userId\":1,\"userName\":\"user1\",\"userAvatar\":\"https://example.com/avatar.jpg\",\"positionId\":1,\"positionName\":\"Java开发工程师\",\"interviewTime\":\"2024-01-01T12:00:00\",\"score\":85.50,\"status\":2,\"reportPath\":\"/reports/1.pdf\",\"startTime\":\"2024-01-01T12:00:00\",\"endTime\":\"2024-01-01T12:45:00\",\"duration\":45,\"createTime\":\"2024-01-01T12:00:00\"}}")))
    @GetMapping("/{id}")
    public Result<InterviewRecordVO> detail(@PathVariable Long id) {
        InterviewRecordVO vo = interviewRecordService.getRecordDetail(id);
        return Result.success(vo);
    }

    @Operation(summary = "查看面试报告")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":\"/reports/1.pdf\"}")))
    @GetMapping("/{id}/report")
    public Result<String> report(@PathVariable Long id) {
        String reportPath = interviewRecordService.getReportPath(id);
        return Result.success(reportPath);
    }
}
