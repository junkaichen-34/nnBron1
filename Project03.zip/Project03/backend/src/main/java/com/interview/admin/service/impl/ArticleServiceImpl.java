package com.interview.admin.service.impl;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.common.exception.BusinessException;
import com.interview.admin.common.result.ResultCode;
import com.interview.admin.entity.Article;
import com.interview.admin.mapper.ArticleMapper;
import com.interview.admin.service.ArticleService;
import com.interview.admin.vo.ArticleVO;
import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Service;

@Service
public class ArticleServiceImpl implements ArticleService {

    private final ArticleMapper articleMapper;

    public ArticleServiceImpl(ArticleMapper articleMapper) {
        this.articleMapper = articleMapper;
    }

    @Override
    public Page<ArticleVO> getArticleList(Integer pageNum, Integer pageSize, String keyword, Integer type, Integer status) {
        Page<Article> page = new Page<>(pageNum, pageSize);
        LambdaQueryWrapper<Article> wrapper = new LambdaQueryWrapper<>();
        
        if (keyword != null && !keyword.isEmpty()) {
            wrapper.like(Article::getTitle, keyword);
        }
        if (type != null) {
            wrapper.eq(Article::getType, type);
        }
        if (status != null) {
            wrapper.eq(Article::getStatus, status);
        }
        
        wrapper.orderByAsc(Article::getSort).orderByDesc(Article::getPublishTime);
        Page<Article> articlePage = articleMapper.selectPage(page, wrapper);
        
        Page<ArticleVO> voPage = new Page<>(articlePage.getCurrent(), articlePage.getSize(), articlePage.getTotal());
        voPage.setRecords(articlePage.getRecords().stream().map(this::convertToVO).toList());
        return voPage;
    }

    @Override
    public ArticleVO getArticleDetail(Long id) {
        Article article = articleMapper.selectById(id);
        if (article == null) {
            throw new BusinessException(ResultCode.ARTICLE_NOT_FOUND);
        }
        return convertToVO(article);
    }

    @Override
    public Article addArticle(Article article) {
        articleMapper.insert(article);
        return article;
    }

    @Override
    public Article updateArticle(Article article) {
        Article existArticle = articleMapper.selectById(article.getId());
        if (existArticle == null) {
            throw new BusinessException(ResultCode.ARTICLE_NOT_FOUND);
        }
        articleMapper.updateById(article);
        return article;
    }

    @Override
    public void updateArticleStatus(Long id, Integer status) {
        Article article = articleMapper.selectById(id);
        if (article == null) {
            throw new BusinessException(ResultCode.ARTICLE_NOT_FOUND);
        }
        article.setStatus(status);
        articleMapper.updateById(article);
    }

    @Override
    public void deleteArticle(Long id) {
        articleMapper.deleteById(id);
    }

    private ArticleVO convertToVO(Article article) {
        ArticleVO vo = new ArticleVO();
        BeanUtils.copyProperties(article, vo);
        return vo;
    }
}
