package com.interview.admin.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.dto.AdminLoginDTO;
import com.interview.admin.dto.AdminRegisterDTO;
import com.interview.admin.entity.Admin;
import com.interview.admin.vo.AdminLoginVO;
import com.interview.admin.vo.AdminVO;

public interface AdminService {

    AdminLoginVO login(AdminLoginDTO loginDTO, String ip);

    AdminVO getAdminInfo(Long adminId);

    Page<AdminVO> getAdminList(Integer pageNum, Integer pageSize, String keyword);

    Admin addAdmin(Admin admin);

    void updateAdminStatus(Long id, Integer status);

    void updatePassword(Long adminId, String oldPassword, String newPassword);

    AdminVO register(AdminRegisterDTO registerDTO);
}
