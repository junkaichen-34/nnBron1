package com.interview.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.interview.admin.entity.InterviewRecord;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface InterviewRecordMapper extends BaseMapper<InterviewRecord> {
}
