package com.interview.admin.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.common.result.Result;
import com.interview.admin.entity.JobPosition;
import com.interview.admin.service.JobPositionService;
import com.interview.admin.vo.JobPositionVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

@Tag(name = "岗位管理", description = "岗位列表、详情、增删改查")
@RestController
@RequestMapping({"/admin/position", "/admin/jobs"})
public class JobPositionController {

    private final JobPositionService jobPositionService;

    public JobPositionController(JobPositionService jobPositionService) {
        this.jobPositionService = jobPositionService;
    }

    @Operation(summary = "获取岗位列表")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"current\":1,\"size\":10,\"total\":0,\"pages\":0,\"records\":[]}}")))
    @GetMapping("/list")
    public Result<Page<JobPositionVO>> list(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String status) {
        Page<JobPositionVO> page = jobPositionService.getPositionList(pageNum, pageSize, keyword, status);
        return Result.success(page);
    }

    @Operation(summary = "获取岗位详情")
    @Parameter(name = "id", description = "岗位ID", required = true, example = "1")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"name\":\"Java开发工程师\",\"code\":\"JAVA-DEV\",\"category\":\"技术\",\"description\":\"负责Java后端开发\",\"requirements\":\"熟悉Spring Boot\",\"salaryRange\":\"15k-25k\",\"location\":\"北京\",\"questionCount\":10,\"sort\":0,\"status\":1,\"createTime\":\"2024-01-01T12:00:00\"}}")))
    @GetMapping("/{id}")
    public Result<JobPositionVO> detail(@PathVariable("id") Long id) {
        JobPositionVO vo = jobPositionService.getPositionDetail(id);
        return Result.success(vo);
    }

    @Operation(summary = "新增/更新岗位")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"name\":\"Java开发工程师\",\"code\":\"JAVA-DEV\",\"status\":1}}")))
    @PostMapping
    public Result<JobPosition> save(@RequestBody JobPosition position) {
        // 如果有id则更新，否则新增
        if (position.getId() != null) {
            JobPosition result = jobPositionService.updatePosition(position);
            return Result.success(result);
        } else {
            JobPosition result = jobPositionService.addPosition(position);
            return Result.success(result);
        }
    }

    @Operation(summary = "更新岗位")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"name\":\"Java开发工程师\",\"code\":\"JAVA-DEV\",\"status\":1}}")))
    @PutMapping
    @PostMapping("/update")
    public Result<JobPosition> update(@RequestBody JobPosition position) {
        JobPosition result = jobPositionService.updatePosition(position);
        return Result.success(result);
    }

    @Operation(summary = "更新岗位（通过路径ID）")
    @Parameter(name = "id", description = "岗位ID", required = true, example = "1")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"name\":\"Java开发工程师\",\"code\":\"JAVA-DEV\",\"status\":1}}")))
    @PostMapping("/{id}")
    public Result<JobPosition> updateByPathId(@PathVariable("id") Long id, @RequestBody JobPosition position) {
        position.setId(id);
        JobPosition result = jobPositionService.updatePosition(position);
        return Result.success(result);
    }

    @Operation(summary = "修改岗位状态")
    @Parameter(name = "id", description = "岗位ID", required = true, example = "1")
    @Parameter(name = "status", description = "状态：已发布、草稿", required = true, example = "已发布")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{}}")))
    @PutMapping("/{id}/status")
    public Result<Void> updateStatus(@PathVariable("id") Long id, @RequestParam("status") String status) {
        jobPositionService.updatePositionStatus(id, status);
        return Result.success();
    }

    @Operation(summary = "删除岗位")
    @Parameter(name = "id", description = "岗位ID", required = true, example = "1")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{}}")))
    @DeleteMapping("/{id}")
    @PostMapping("/delete/{id}")
    public Result<Void> delete(@PathVariable("id") Long id) {
        jobPositionService.deletePosition(id);
        return Result.success();
    }

    @Operation(summary = "调试：查看所有岗位（包括已删除）")
    @GetMapping("/debug/all")
    public Result<java.util.List<JobPosition>> debugAll() {
        java.util.List<JobPosition> list = jobPositionService.getAllPositionsIncludingDeleted();
        return Result.success(list);
    }
}
