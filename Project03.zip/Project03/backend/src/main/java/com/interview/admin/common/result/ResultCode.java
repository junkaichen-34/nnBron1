package com.interview.admin.common.result;

public enum ResultCode {

    SUCCESS(200, "操作成功"),
    ERROR(500, "操作失败"),

    UNAUTHORIZED(401, "未授权，请先登录"),
    FORBIDDEN(403, "无权限访问"),
    NOT_FOUND(404, "资源不存在"),

    PARAM_ERROR(400, "参数错误"),

    USERNAME_EXISTS(1001, "用户名已存在"),
    USER_NOT_FOUND(1002, "用户不存在"),
    PASSWORD_ERROR(1003, "密码错误"),
    ACCOUNT_DISABLED(1004, "账号已被禁用"),

    ADMIN_NOT_FOUND(1101, "管理员不存在"),
    ADMIN_PASSWORD_ERROR(1102, "管理员密码错误"),
    ADMIN_DISABLED(1103, "管理员账号已被禁用"),

    POSITION_NOT_FOUND(2001, "岗位不存在"),
    POSITION_CODE_EXISTS(2002, "岗位编码已存在"),
    QUESTION_NOT_FOUND(2003, "题目不存在"),
    INTERVIEW_SESSION_NOT_FOUND(2004, "面试会话不存在"),
    INTERVIEW_RECORD_NOT_FOUND(2005, "面试记录不存在"),
    ARTICLE_NOT_FOUND(2006, "推荐内容不存在");

    private final Integer code;
    private final String message;

    ResultCode(Integer code, String message) {
        this.code = code;
        this.message = message;
    }

    public Integer getCode() {
        return code;
    }

    public String getMessage() {
        return message;
    }
}
