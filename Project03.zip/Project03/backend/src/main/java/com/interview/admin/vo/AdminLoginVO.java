package com.interview.admin.vo;

import io.swagger.v3.oas.annotations.media.Schema;

@Schema(description = "管理员登录响应对象")
public class AdminLoginVO {

    @Schema(description = "访问令牌", example = "eyJhbGciOiJIUzM4NCJ9...")
    private String accessToken;

    @Schema(description = "刷新令牌", example = "eyJhbGciOiJIUzM4NCJ9...")
    private String refreshToken;

    @Schema(description = "令牌过期时间(秒)", example = "86400")
    private Long expiresIn;

    @Schema(description = "管理员信息")
    private AdminVO adminInfo;

    public AdminLoginVO() {
    }

    public AdminLoginVO(String accessToken, String refreshToken, Long expiresIn, AdminVO adminInfo) {
        this.accessToken = accessToken;
        this.refreshToken = refreshToken;
        this.expiresIn = expiresIn;
        this.adminInfo = adminInfo;
    }

    public String getAccessToken() {
        return accessToken;
    }

    public void setAccessToken(String accessToken) {
        this.accessToken = accessToken;
    }

    public String getRefreshToken() {
        return refreshToken;
    }

    public void setRefreshToken(String refreshToken) {
        this.refreshToken = refreshToken;
    }

    public Long getExpiresIn() {
        return expiresIn;
    }

    public void setExpiresIn(Long expiresIn) {
        this.expiresIn = expiresIn;
    }

    public AdminVO getAdminInfo() {
        return adminInfo;
    }

    public void setAdminInfo(AdminVO adminInfo) {
        this.adminInfo = adminInfo;
    }
}
