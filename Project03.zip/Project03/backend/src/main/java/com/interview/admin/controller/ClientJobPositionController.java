package com.interview.admin.controller;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.common.result.Result;
import com.interview.admin.service.JobPositionService;
import com.interview.admin.vo.JobPositionVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.web.bind.annotation.*;

@Tag(name = "客户端-岗位管理", description = "客户端查看岗位信息（只读）")
@RestController
@RequestMapping("/client/position")
public class ClientJobPositionController {

    private final JobPositionService jobPositionService;

    public ClientJobPositionController(JobPositionService jobPositionService) {
        this.jobPositionService = jobPositionService;
    }

    @Operation(summary = "获取岗位列表")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"current\":1,\"size\":10,\"total\":0,\"pages\":0,\"records\":[]}}")))
    @GetMapping("/list")
    public Result<Page<JobPositionVO>> list(
            @RequestParam(defaultValue = "1") Integer pageNum,
            @RequestParam(defaultValue = "10") Integer pageSize,
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String category) {
        Page<JobPositionVO> page = jobPositionService.getPositionList(pageNum, pageSize, keyword, category, "已发布");
        return Result.success(page);
    }

    @Operation(summary = "获取岗位详情")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":1,\"name\":\"Java开发工程师\",\"code\":\"JAVA-DEV\",\"category\":\"研发\",\"description\":\"负责Java后端开发\",\"requirements\":\"熟悉Spring Boot\",\"location\":\"北京\",\"status\":\"已发布\",\"publishTime\":\"2024-01-01T12:00:00\",\"createTime\":\"2024-01-01T12:00:00\"}}")))
    @GetMapping("/{id}")
    public Result<JobPositionVO> detail(@PathVariable Long id) {
        JobPositionVO vo = jobPositionService.getPositionDetail(id);
        return Result.success(vo);
    }
}
