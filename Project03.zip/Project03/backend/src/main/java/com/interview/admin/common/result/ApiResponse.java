package com.interview.admin.common.result;

import io.swagger.v3.oas.annotations.media.Schema;

import java.io.Serializable;

/**
 * 统一API响应对象 - 用于Swagger文档生成，避免泛型解析问题
 */
@Schema(description = "统一API响应")
public class ApiResponse implements Serializable {

    private static final long serialVersionUID = 1L;

    @Schema(description = "响应码：200-成功，401-未授权，500-系统错误", example = "200", requiredMode = Schema.RequiredMode.REQUIRED)
    private Integer code;

    @Schema(description = "响应消息", example = "操作成功", requiredMode = Schema.RequiredMode.REQUIRED)
    private String message;

    @Schema(description = "响应数据（根据接口不同，数据类型不同）", nullable = true)
    private Object data;

    public ApiResponse() {
    }

    public ApiResponse(Integer code, String message, Object data) {
        this.code = code;
        this.message = message;
        this.data = data;
    }

    public static ApiResponse success() {
        return new ApiResponse(200, "操作成功", null);
    }

    public static ApiResponse success(Object data) {
        return new ApiResponse(200, "操作成功", data);
    }

    public static ApiResponse error(Integer code, String message) {
        return new ApiResponse(code, message, null);
    }

    // Getters and Setters
    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }
}
