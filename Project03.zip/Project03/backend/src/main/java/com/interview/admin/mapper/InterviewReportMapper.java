package com.interview.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.interview.admin.entity.InterviewReport;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

@Mapper
public interface InterviewReportMapper extends BaseMapper<InterviewReport> {

    @Select("SELECT * FROM interview_report WHERE session_id = #{sessionId} AND is_deleted = 0")
    InterviewReport selectBySessionId(Long sessionId);
}
