package com.interview.admin.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.interview.admin.entity.JobPosition;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface JobPositionMapper extends BaseMapper<JobPosition> {
}
