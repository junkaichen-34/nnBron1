package com.interview.admin.config;

import com.interview.admin.common.result.Result;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.media.Schema;
import org.springdoc.core.utils.SpringDocUtils;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDateTime;
import java.util.Map;

@Configuration
public class SpringDocConfig {

    static {
        // 配置 SpringDoc 正确处理 LocalDateTime
        SpringDocUtils.getConfig().replaceWithSchema(LocalDateTime.class,
                new Schema<String>().type("string").format("date-time").example("2024-01-01T12:00:00"));
    }

    @Bean
    public OpenAPI customOpenAPI() {
        return new OpenAPI()
                .info(new Info()
                        .title("AI模拟面试平台 - 后台管理系统API")
                        .description("后台管理系统接口文档")
                        .version("1.0.0")
                        .contact(new Contact()
                                .name("Admin Team"))
                        .license(new License()
                                .name("Apache 2.0")));
    }
}
