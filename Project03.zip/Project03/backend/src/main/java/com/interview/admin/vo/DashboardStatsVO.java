package com.interview.admin.vo;

import io.swagger.v3.oas.annotations.media.Schema;
import java.util.List;

@Schema(description = "仪表盘统计数据视图对象")
public class DashboardStatsVO {

    @Schema(description = "总用户数", example = "1000")
    private Long totalUsers;

    @Schema(description = "活跃用户", example = "500")
    private Long activeUsers;

    @Schema(description = "总岗位数", example = "50")
    private Long totalPositions;

    @Schema(description = "总题数", example = "200")
    private Long totalQuestions;

    @Schema(description = "今日面试数", example = "10")
    private Long todayInterviews;

    @Schema(description = "总面试数", example = "100")
    private Long totalInterviews;

    @Schema(description = "本月新增用户", example = "50")
    private Long thisMonthNewUsers;

    @Schema(description = "最近注册用户列表")
    private List<UserVO> recentUsers;

    public DashboardStatsVO() {
    }

    public DashboardStatsVO(Long totalUsers, Long activeUsers, Long totalPositions, Long totalQuestions,
                           Long todayInterviews, Long totalInterviews, Long thisMonthNewUsers, List<UserVO> recentUsers) {
        this.totalUsers = totalUsers;
        this.activeUsers = activeUsers;
        this.totalPositions = totalPositions;
        this.totalQuestions = totalQuestions;
        this.todayInterviews = todayInterviews;
        this.totalInterviews = totalInterviews;
        this.thisMonthNewUsers = thisMonthNewUsers;
        this.recentUsers = recentUsers;
    }

    public Long getTotalUsers() {
        return totalUsers;
    }

    public void setTotalUsers(Long totalUsers) {
        this.totalUsers = totalUsers;
    }

    public Long getActiveUsers() {
        return activeUsers;
    }

    public void setActiveUsers(Long activeUsers) {
        this.activeUsers = activeUsers;
    }

    public Long getTotalPositions() {
        return totalPositions;
    }

    public void setTotalPositions(Long totalPositions) {
        this.totalPositions = totalPositions;
    }

    public Long getTotalQuestions() {
        return totalQuestions;
    }

    public void setTotalQuestions(Long totalQuestions) {
        this.totalQuestions = totalQuestions;
    }

    public Long getTodayInterviews() {
        return todayInterviews;
    }

    public void setTodayInterviews(Long todayInterviews) {
        this.todayInterviews = todayInterviews;
    }

    public Long getTotalInterviews() {
        return totalInterviews;
    }

    public void setTotalInterviews(Long totalInterviews) {
        this.totalInterviews = totalInterviews;
    }

    public Long getThisMonthNewUsers() {
        return thisMonthNewUsers;
    }

    public void setThisMonthNewUsers(Long thisMonthNewUsers) {
        this.thisMonthNewUsers = thisMonthNewUsers;
    }

    public List<UserVO> getRecentUsers() {
        return recentUsers;
    }

    public void setRecentUsers(List<UserVO> recentUsers) {
        this.recentUsers = recentUsers;
    }
}
