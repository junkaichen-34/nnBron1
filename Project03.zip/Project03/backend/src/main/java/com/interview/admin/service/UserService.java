package com.interview.admin.service;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.interview.admin.entity.User;
import com.interview.admin.vo.UserVO;

public interface UserService {

    Page<UserVO> getUserList(Integer pageNum, Integer pageSize, String keyword, Integer status);

    UserVO getUserDetail(Long id);

    void updateUserStatus(Long id, Integer status);

    void deleteUser(Long id);
}
