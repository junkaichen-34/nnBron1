package com.interview.admin.config;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import org.springframework.boot.autoconfigure.jackson.Jackson2ObjectMapperBuilderCustomizer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

@Configuration
public class JacksonConfig {

    private static final String DATE_TIME_PATTERN = "yyyy-MM-dd HH:mm:ss";
    private static final String DATE_PATTERN = "yyyy-MM-dd";
    private static final String ISO_DATE_TIME_PATTERN = "yyyy-MM-dd'T'HH:mm:ss";

    @Bean
    public Jackson2ObjectMapperBuilderCustomizer jackson2ObjectMapperBuilderCustomizer() {
        return builder -> {
            // 序列化
            builder.serializerByType(LocalDateTime.class,
                    new LocalDateTimeSerializer(DateTimeFormatter.ofPattern(DATE_TIME_PATTERN)));
            // 反序列化 - 支持多种格式
            builder.deserializerByType(LocalDateTime.class, new JsonDeserializer<LocalDateTime>() {
                @Override
                public LocalDateTime deserialize(JsonParser p, DeserializationContext ctxt) throws IOException {
                    String text = p.getText();
                    if (text == null || text.isEmpty()) {
                        return null;
                    }
                    try {
                        // 尝试解析完整日期时间格式：yyyy-MM-dd HH:mm:ss
                        return LocalDateTime.parse(text, DateTimeFormatter.ofPattern(DATE_TIME_PATTERN));
                    } catch (DateTimeParseException e1) {
                        try {
                            // 尝试解析ISO格式：yyyy-MM-dd'T'HH:mm:ss
                            return LocalDateTime.parse(text, DateTimeFormatter.ofPattern(ISO_DATE_TIME_PATTERN));
                        } catch (DateTimeParseException e2) {
                            try {
                                // 尝试解析日期格式：yyyy-MM-dd，自动补全时间为 00:00:00
                                LocalDate date = LocalDate.parse(text, DateTimeFormatter.ofPattern(DATE_PATTERN));
                                return LocalDateTime.of(date, LocalTime.MIN);
                            } catch (DateTimeParseException e3) {
                                throw new RuntimeException("无法解析日期时间: " + text + ", 支持的格式: yyyy-MM-dd HH:mm:ss, yyyy-MM-dd'T'HH:mm:ss, yyyy-MM-dd");
                            }
                        }
                    }
                }
            });
            // 禁用将日期写成时间戳
            builder.featuresToDisable(SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);
        };
    }
}
