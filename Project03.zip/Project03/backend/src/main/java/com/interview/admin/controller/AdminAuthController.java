package com.interview.admin.controller;

import com.interview.admin.common.result.Result;
import com.interview.admin.dto.AdminLoginDTO;
import com.interview.admin.dto.AdminRegisterDTO;
import com.interview.admin.dto.UpdatePasswordDTO;
import com.interview.admin.security.SecurityContext;
import com.interview.admin.service.AdminService;
import com.interview.admin.vo.AdminLoginVO;
import com.interview.admin.vo.AdminVO;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.*;

@Tag(name = "管理员认证", description = "管理员注册、登录、登出、获取信息")
@RestController
@RequestMapping("/admin/auth")
public class AdminAuthController {

    private final AdminService adminService;

    public AdminAuthController(AdminService adminService) {
        this.adminService = adminService;
    }

    @Operation(summary = "管理员注册")
    @ApiResponse(responseCode = "200", description = "注册成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"id\":2,\"username\":\"newadmin\",\"realName\":\"新管理员\",\"phone\":\"13800138000\",\"email\":\"admin@example.com\",\"status\":1,\"createTime\":\"2024-01-01T12:00:00\"}}")))
    @PostMapping("/register")
    public Result<AdminVO> register(@Valid @RequestBody AdminRegisterDTO registerDTO) {
        AdminVO adminVO = adminService.register(registerDTO);
        return Result.success(adminVO);
    }

    @Operation(summary = "管理员登录")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{\"accessToken\":\"eyJhbGciOiJIUzM4NCJ9...\",\"refreshToken\":\"eyJhbGciOiJIUzM4NCJ9...\",\"expiresIn\":86400,\"adminInfo\":{\"id\":1,\"username\":\"admin\",\"realName\":\"系统管理员\",\"phone\":\"13800138000\",\"email\":\"admin@example.com\",\"avatar\":\"https://example.com/avatar.jpg\",\"status\":1,\"lastLoginTime\":\"2024-01-01T12:00:00\",\"createTime\":\"2024-01-01T12:00:00\"}}}")))
    @PostMapping("/login")
    public Result<AdminLoginVO> login(@Valid @RequestBody AdminLoginDTO loginDTO, HttpServletRequest request) {
        String ip = getClientIp(request);
        AdminLoginVO loginVO = adminService.login(loginDTO, ip);
        return Result.success(loginVO);
    }

    @Operation(summary = "获取当前管理员信息")
    @ApiResponse(responseCode = "200", description = "成功")
    @GetMapping("/info")
    public Result<AdminVO> getInfo() {
        Long adminId = 1L; // 临时硬编码
        AdminVO adminVO = adminService.getAdminInfo(adminId);
        return Result.success(adminVO);
    }

    @Operation(summary = "管理员登出")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{}}")))
    @PostMapping("/logout")
    public Result<Void> logout() {
        return Result.success();
    }

    @Operation(summary = "修改密码")
    @ApiResponse(responseCode = "200", description = "成功",
            content = @Content(mediaType = "application/json",
                    schema = @Schema(type = "object", example = "{\"code\":200,\"message\":\"操作成功\",\"data\":{}}")))
    @PutMapping("/password")
    public Result<Void> updatePassword(@RequestBody UpdatePasswordDTO updatePasswordDTO) {
        Long adminId = SecurityContext.getCurrentUserId();
        adminService.updatePassword(adminId, updatePasswordDTO.getOldPassword(), updatePasswordDTO.getNewPassword());
        return Result.success();
    }

    private String getClientIp(HttpServletRequest request) {
        String ip = request.getHeader("X-Forwarded-For");
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getHeader("WL-Proxy-Client-IP");
        }
        if (ip == null || ip.isEmpty() || "unknown".equalsIgnoreCase(ip)) {
            ip = request.getRemoteAddr();
        }
        return ip;
    }
}
