package com.interview.admin;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.interview.admin.mapper")
public class InterviewAdminApplication {

    public static void main(String[] args) {
        SpringApplication.run(InterviewAdminApplication.class, args);
        System.out.println("======================================");
        System.out.println("  AI模拟面试平台 - 后台管理系统已启动  ");
        System.out.println("  Knife4j文档: http://localhost:8080/api/doc.html");
        System.out.println("  Swagger UI: http://localhost:8080/api/swagger-ui/index.html");
        System.out.println("======================================");
    }
}
