# AI模拟面试平台 - 客户端前端 API文档

## 基础信息

| 项目 | 内容 |
|------|------|
| **基础URL** | `http://后端IP:8080/api` |
| **协议** | HTTP |
| **数据格式** | JSON |
| **编码** | UTF-8 |

---

## 错误码对照表

| 错误码 | 含义 | 说明 |
|--------|------|------|
| 200 | 操作成功 | 请求处理成功 |
| 400 | 参数错误 | 请求参数校验失败 |
| 404 | 资源不存在 | 请求的资源不存在 |
| 500 | 系统异常 | 服务器内部错误 |
| 2001 | 岗位不存在 | 查询的岗位ID不存在或已被删除 |
| 2002 | 文章不存在 | 查询的文章ID不存在或已被删除 |
| 2003 | 面试记录不存在 | 查询的面试记录ID不存在 |

---

## 数据库表对照

| 后台管理表 | 客户端数据库表 | 说明 |
|-----------|---------------|------|
| article | article | 课程/文章推荐表 |
| job_position | job_position | 岗位表 |
| interview_record | interview_session | 面试会话表 |

---

## 接口列表

### 一、课程/文章管理

#### 1. 获取课程/文章列表

**接口信息**
- **请求方式：** GET
- **请求路径：** `/client/article/list`
- **接口说明：** 分页查询课程/文章列表

**请求参数（Query）**

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| pageNum | int | 否 | 1 | 页码 |
| pageSize | int | 否 | 10 | 每页数量 |
| type | int | 否 | - | 类型：1-课程，2-文章 |
| status | int | 否 | 1 | 状态：0-禁用，1-启用 |

**请求示例**
```
GET /client/article/list?pageNum=1&pageSize=10&type=1&status=1
```

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "records": [
      {
        "id": 1,
        "title": "Java面试核心知识点精讲",
        "category": 0,
        "type": 1,
        "coverUrl": "/covers/java_interview.jpg",
        "linkUrl": "https://example.com/course/java-interview",
        "description": "全面讲解Java面试高频考点",
        "author": "李老师",
        "source": "慕课网",
        "sort": 1,
        "viewCount": 100,
        "status": 1,
        "publishTime": "2024-03-25T10:00:00"
      }
    ],
    "total": 50,
    "size": 10,
    "current": 1,
    "pages": 5
  }
}
```

---

#### 2. 获取课程/文章详情

**接口信息**
- **请求方式：** GET
- **请求路径：** `/client/article/{id}`
- **接口说明：** 根据ID查询课程/文章详情

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 课程/文章ID |

**请求示例**
```
GET /client/article/1
```

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "title": "Java面试核心知识点精讲",
    "category": 0,
    "type": 1,
    "coverUrl": "/covers/java_interview.jpg",
    "linkUrl": "https://example.com/course/java-interview",
    "description": "全面讲解Java面试高频考点，包括集合、多线程、JVM等",
    "author": "李老师",
    "source": "慕课网",
    "sort": 1,
    "viewCount": 100,
    "status": 1,
    "publishTime": "2024-03-25T10:00:00",
    "createTime": "2024-03-25T10:00:00"
  }
}
```

**错误响应**
```json
{
  "code": 2002,
  "message": "文章不存在"
}
```

---

### 二、岗位管理

#### 1. 获取岗位列表

**接口信息**
- **请求方式：** GET
- **请求路径：** `/client/position/list`
- **接口说明：** 分页查询岗位列表（只返回已发布状态）

**请求参数（Query）**

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| pageNum | int | 否 | 1 | 页码 |
| pageSize | int | 否 | 10 | 每页数量 |
| category | string | 否 | - | 岗位分类（如：研发、产品、设计） |

**请求示例**
```
GET /client/position/list?pageNum=1&pageSize=10&category=研发
```

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "records": [
      {
        "id": 1,
        "name": "前端开发工程师",
        "code": "FE_DEV",
        "category": "研发",
        "description": "负责Web前端开发工作",
        "requirements": "熟悉Vue、React等前端框架",
        "location": "北京",
        "status": "已发布",
        "publishTime": "2024-03-20T10:00:00"
      },
      {
        "id": 2,
        "name": "后端开发工程师",
        "code": "BE_DEV",
        "category": "研发",
        "description": "负责服务端开发工作",
        "requirements": "熟悉Java、Spring Boot",
        "location": "北京",
        "status": "已发布",
        "publishTime": "2024-03-21T11:00:00"
      }
    ],
    "total": 5,
    "size": 10,
    "current": 1,
    "pages": 1
  }
}
```

---

#### 2. 获取岗位详情

**接口信息**
- **请求方式：** GET
- **请求路径：** `/client/position/{id}`
- **接口说明：** 根据ID查询岗位详情

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 岗位ID |

**请求示例**
```
GET /client/position/1
```

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "name": "前端开发工程师",
    "code": "FE_DEV",
    "category": "研发",
    "description": "负责Web前端开发工作",
    "requirements": "熟悉Vue、React等前端框架，有3年以上经验",
    "location": "北京",
    "status": "已发布",
    "publishTime": "2024-03-20T10:00:00",
    "createTime": "2024-03-20T10:00:00"
  }
}
```

**错误响应**
```json
{
  "code": 2001,
  "message": "岗位不存在"
}
```

---

### 三、面试记录管理

#### 1. 获取面试记录列表

**接口信息**
- **请求方式：** GET
- **请求路径：** `/client/interview-record/list`
- **接口说明：** 分页查询面试记录列表

**请求参数（Query）**

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| pageNum | int | 否 | 1 | 页码 |
| pageSize | int | 否 | 10 | 每页数量 |
| userId | long | 否 | - | 用户ID筛选 |
| positionId | long | 否 | - | 岗位ID筛选 |

**请求示例**
```
GET /client/interview-record/list?pageNum=1&pageSize=10&userId=1
```

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "records": [
      {
        "id": 1,
        "userId": 1,
        "userName": "张三",
        "userAvatar": "https://example.com/avatar.jpg",
        "positionId": 1,
        "positionName": "Java开发工程师",
        "interviewTime": "2024-03-25T14:30:00",
        "score": 85.50,
        "status": 2,
        "duration": 45,
        "hasReport": 1,
        "createTime": "2024-03-25T14:30:00"
      },
      {
        "id": 2,
        "userId": 2,
        "userName": "李四",
        "userAvatar": "https://example.com/avatar2.jpg",
        "positionId": 2,
        "positionName": "前端开发工程师",
        "interviewTime": "2024-03-26T10:00:00",
        "score": 78.00,
        "status": 2,
        "duration": 38,
        "hasReport": 1,
        "createTime": "2024-03-26T10:00:00"
      }
    ],
    "total": 20,
    "size": 10,
    "current": 1,
    "pages": 2
  }
}
```

**字段说明**

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | long | 面试记录ID |
| userId | long | 用户ID |
| userName | string | 用户名 |
| userAvatar | string | 用户头像URL |
| positionId | long | 岗位ID |
| positionName | string | 岗位名称 |
| interviewTime | datetime | 面试时间 |
| score | decimal | 面试得分（0-100） |
| status | int | 面试状态：0-未开始, 1-进行中, 2-已完成, 3-已中断 |
| duration | int | 面试时长（分钟） |
| hasReport | int | 是否有报告：0-否, 1-是 |
| createTime | datetime | 创建时间 |

---

#### 2. 获取面试记录详情

**接口信息**
- **请求方式：** GET
- **请求路径：** `/client/interview-record/{id}`
- **接口说明：** 根据ID查询面试记录详情

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 面试记录ID |

**请求示例**
```
GET /client/interview-record/1
```

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "userId": 1,
    "userName": "张三",
    "userAvatar": "https://example.com/avatar.jpg",
    "positionId": 1,
    "positionName": "Java开发工程师",
    "interviewMode": "text",
    "interviewStatus": 2,
    "startTime": "2024-03-25T14:30:00",
    "endTime": "2024-03-25T15:15:00",
    "duration": 45,
    "totalScore": 85.50,
    "interviewEvaluation": "优秀",
    "hasReport": 1,
    "reportPath": "/reports/1.pdf",
    "createTime": "2024-03-25T14:30:00",
    "updateTime": "2024-03-25T15:15:00"
  }
}
```

**字段说明**

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | long | 面试记录ID |
| userId | long | 用户ID |
| userName | string | 用户名 |
| userAvatar | string | 用户头像URL |
| positionId | long | 岗位ID |
| positionName | string | 岗位名称 |
| interviewMode | string | 面试模式：text-文本, voice-语音 |
| interviewStatus | int | 面试状态：0-未开始, 1-进行中, 2-已完成, 3-已中断 |
| startTime | datetime | 开始时间 |
| endTime | datetime | 结束时间 |
| duration | int | 面试时长（分钟） |
| totalScore | decimal | 综合得分（0-100） |
| interviewEvaluation | string | 评价等级：优秀、良好、一般、需改进 |
| hasReport | int | 是否有报告：0-否, 1-是 |
| reportPath | string | 报告文件路径 |
| createTime | datetime | 创建时间 |
| updateTime | datetime | 更新时间 |

**错误响应**
```json
{
  "code": 2003,
  "message": "面试记录不存在"
}
```

---

#### 3. 查看面试报告

**接口信息**
- **请求方式：** GET
- **请求路径：** `/client/interview-record/{id}/report`
- **接口说明：** 获取面试报告文件路径或URL

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 面试记录ID |

**请求示例**
```
GET /client/interview-record/1/report
```

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": "/reports/1.pdf"
}
```

**说明**
- 返回的报告路径需要拼接基础URL访问
- 例如：`http://后端IP:8080/reports/1.pdf`

---

## 附录

### 时间格式说明

所有时间字段统一使用 ISO 8601 格式：
- **示例：** `2024-03-20T10:00:00`

### 文章类型

| 值 | 说明 |
|----|------|
| 1 | 课程 |
| 2 | 文章 |

### 文章分类

| 值 | 说明 |
|----|------|
| 0 | Java后端 |
| 1 | Web前端 |
| 2 | Python |
| 3 | Go后端 |
| 4 | 通用 |

### 文章状态

| 值 | 说明 |
|----|------|
| 0 | 禁用 |
| 1 | 启用 |

### 岗位状态

| 值 | 说明 |
|----|------|
| 已发布 | 岗位已发布，对外可见 |
| 草稿 | 岗位为草稿状态，对外不可见 |

### 面试状态

| 值 | 说明 |
|----|------|
| 0 | 未开始 |
| 1 | 进行中 |
| 2 | 已完成 |
| 3 | 已中断 |

### 岗位分类示例

- 研发
- 产品
- 设计
- 运营

### 数据库表结构

#### article 表（课程/文章推荐表）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | bigint | 主键ID |
| title | varchar(200) | 标题 |
| type | tinyint | 类型：1-课程，2-文章 |
| category | int | 分类：0-Java后端, 1-Web前端, 2-Python, 3-Go后端, 4-通用 |
| cover_url | varchar(500) | 封面图片URL |
| link_url | varchar(500) | 链接地址 |
| description | text | 描述/简介 |
| author | varchar(100) | 作者 |
| source | varchar(100) | 来源 |
| sort | int | 排序（数字越小越靠前） |
| view_count | int | 浏览次数 |
| status | tinyint | 状态：0-禁用，1-启用 |
| publish_time | datetime | 发布时间 |
| create_time | datetime | 创建时间 |
| update_time | datetime | 更新时间 |
| deleted | tinyint | 删除标记：0-未删除，1-已删除 |

#### job_position 表（岗位表）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| id | bigint | 主键ID |
| name | varchar(100) | 岗位名称 |
| code | varchar(50) | 岗位编码（唯一标识） |
| category | varchar(50) | 岗位分类 |
| description | text | 岗位描述 |
| requirements | text | 岗位要求 |
| location | varchar(100) | 工作地点 |
| status | varchar(20) | 状态：已发布、草稿 |
| publish_time | datetime | 发布时间 |
| create_time | datetime | 创建时间 |
| update_time | datetime | 更新时间 |
| deleted | tinyint | 删除标记：0-未删除，1-已删除 |

#### interview_session 表（面试会话表）

| 字段名 | 类型 | 说明 |
|--------|------|------|
| session_id | bigint | 面试会话ID |
| user_id | bigint | 用户ID |
| position_id | bigint | 岗位ID |
| resume_id | bigint | 简历ID |
| interview_mode | varchar(50) | 面试模式：text-文本, voice-语音 |
| interview_status | tinyint | 状态：0-未开始, 1-进行中, 2-已完成, 3-已中断 |
| start_time | datetime | 开始时间 |
| end_time | datetime | 结束时间 |
| interview_duration | int | 面试时长（秒） |
| total_score | decimal(5,2) | 综合得分（0-100） |
| interview_evaluation | varchar(50) | 评价等级：优秀、良好、一般、需改进 |
| has_report | tinyint | 是否有报告：0-否, 1-是 |
| create_time | datetime | 创建时间 |
| update_time | datetime | 更新时间 |
