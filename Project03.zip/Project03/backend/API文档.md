# AI模拟面试平台 - 后台管理系统 API文档

## 基础信息

| 项目 | 内容 |
|------|------|
| **基础URL** | `http://localhost:8080/api` |
| **协议** | HTTP |
| **数据格式** | JSON |
| **编码** | UTF-8 |

## 认证方式

采用 **Bearer Token** 认证机制：

1. 调用登录接口获取 `accessToken`
2. 在后续请求的 Header 中添加：`Authorization: Bearer {accessToken}`

---

## 错误码对照表

| 错误码 | 含义 | 说明 |
|--------|------|------|
| 200 | 操作成功 | 请求处理成功 |
| 400 | 参数错误 | 请求参数校验失败 |
| 401 | 未授权 | Token无效或已过期，需重新登录 |
| 403 | 无权限 | 没有访问该资源的权限 |
| 404 | 资源不存在 | 请求的资源不存在 |
| 500 | 系统异常 | 服务器内部错误 |
| 1001 | 用户名或密码错误 | 登录凭证错误 |
| 1002 | 用户不存在 | 查询的用户ID不存在 |
| 1101 | 管理员不存在 | 管理员账号不存在 |
| 2001 | 岗位不存在 | 查询的岗位ID不存在 |
| 2002 | 岗位编码已存在 | 新增的岗位编码已存在 |
| 3001 | 文章不存在 | 查询的文章ID不存在 |

---

## 接口列表

### 一、认证模块

#### 1. 管理员登录

**接口信息**
- **请求方式：** POST
- **请求路径：** `/admin/auth/login`
- **接口说明：** 管理员登录获取Token

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| username | string | 是 | 用户名 |
| password | string | 是 | 密码 |

**请求示例**
```json
{
  "username": "admin",
  "password": "123456"
}
```

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "accessToken": "eyJhbGciOiJIUzM4NCJ9...",
    "refreshToken": "eyJhbGciOiJIUzM4NCJ9...",
    "expiresIn": 86400,
    "adminInfo": {
      "id": 1,
      "username": "admin",
      "realName": "系统管理员",
      "phone": "",
      "email": "",
      "avatar": "",
      "status": "已发布"
    }
  }
}
```

---

#### 2. 获取当前管理员信息

**接口信息**
- **请求方式：** GET
- **请求路径：** `/admin/auth/info`
- **接口说明：** 获取当前登录管理员的信息

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "username": "admin",
    "realName": "系统管理员",
    "phone": "",
    "email": "",
    "avatar": "",
    "status": "已发布",
    "lastLoginTime": "2024-01-01T12:00:00",
    "createTime": "2024-01-01T12:00:00"
  }
}
```

---

#### 3. 修改密码

**接口信息**
- **请求方式：** PUT
- **请求路径：** `/admin/auth/password`
- **接口说明：** 修改当前登录管理员的密码

**请求参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| oldPassword | string | 是 | 旧密码 |
| newPassword | string | 是 | 新密码（6-20位） |

---

### 二、用户管理（sys_user表）

**数据库表结构：**
- 主键：`user_id` bigint
- 字段：username, password, real_name, avatar, role_type, phone, email, status, register_time, last_login_time, create_time, update_time, remark, interview_count, avg_score

#### 1. 获取用户列表

**接口信息**
- **请求方式：** GET
- **请求路径：** `/admin/user/list`
- **接口说明：** 分页查询用户列表

**请求参数（Query）**

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| pageNum | int | 否 | 1 | 页码 |
| pageSize | int | 否 | 10 | 每页数量 |
| keyword | string | 否 | - | 搜索关键词（用户名/真实姓名） |
| status | int | 否 | - | 状态：0-禁用，1-正常 |

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "records": [
      {
        "userId": 1,
        "username": "zhangsan",
        "realName": "张三",
        "phone": "13800138000",
        "email": "zhangsan@example.com",
        "avatar": "https://example.com/avatar.jpg",
        "roleType": 2,
        "status": 1,
        "interviewCount": 5,
        "avgScore": 85.50,
        "lastLoginTime": "2024-01-01T12:00:00",
        "createTime": "2024-01-01T12:00:00"
      }
    ],
    "total": 100,
    "size": 10,
    "current": 1,
    "pages": 10
  }
}
```

---

#### 2. 获取用户详情

**接口信息**
- **请求方式：** GET
- **请求路径：** `/admin/user/{id}`
- **接口说明：** 根据ID查询用户详情

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 用户ID (user_id) |

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "userId": 1,
    "username": "zhangsan",
    "realName": "张三",
    "phone": "13800138000",
    "email": "zhangsan@example.com",
    "avatar": "https://example.com/avatar.jpg",
    "roleType": 2,
    "status": 1,
    "interviewCount": 5,
    "avgScore": 85.50,
    "remark": "备注信息",
    "registerTime": "2024-01-01T12:00:00",
    "lastLoginTime": "2024-01-01T12:00:00",
    "createTime": "2024-01-01T12:00:00"
  }
}
```

---

#### 3. 更新用户状态

**接口信息**
- **请求方式：** PUT
- **请求路径：** `/admin/user/{id}/status`
- **接口说明：** 启用/禁用用户账号

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 用户ID |

**请求参数（Query）**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| status | int | 是 | 状态：0-禁用，1-正常 |

---

### 三、岗位管理（job_position表）

**数据库表结构：**
- 主键：`id` bigint
- 字段：name, code, category, description, requirements, location, status, publish_time, create_time, update_time, deleted

#### 1. 获取岗位列表

**接口信息**
- **请求方式：** GET
- **请求路径：** `/admin/position/list`
- **接口说明：** 分页查询岗位列表

**请求参数（Query）**

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| pageNum | int | 否 | 1 | 页码 |
| pageSize | int | 否 | 10 | 每页数量 |
| keyword | string | 否 | - | 搜索关键词（岗位名称/编码） |
| status | string | 否 | - | 状态：已发布、草稿 |

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "records": [
      {
        "id": 1,
        "name": "Java开发工程师",
        "code": "JAVA-DEV",
        "category": "研发",
        "description": "负责Java后端开发",
        "requirements": "熟悉Spring Boot",
        "location": "北京",
        "status": "已发布",
        "publishTime": "2024-01-01T12:00:00",
        "createTime": "2024-01-01T12:00:00"
      }
    ],
    "total": 50,
    "size": 10,
    "current": 1,
    "pages": 5
  }
}
```

---

#### 2. 获取岗位详情

**接口信息**
- **请求方式：** GET
- **请求路径：** `/admin/position/{id}`
- **接口说明：** 根据ID查询岗位详情

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 岗位ID |

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "name": "Java开发工程师",
    "code": "JAVA-DEV",
    "category": "研发",
    "description": "负责Java后端开发",
    "requirements": "熟悉Spring Boot",
    "location": "北京",
    "status": "已发布",
    "publishTime": "2024-01-01T12:00:00",
    "createTime": "2024-01-01T12:00:00"
  }
}
```

---

#### 3. 新增岗位

**接口信息**
- **请求方式：** POST
- **请求路径：** `/admin/position`
- **接口说明：** 新增岗位信息

**请求参数（Body）**

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| name | string | 是 | - | 岗位名称 |
| code | string | 否 | - | 岗位编码（唯一，可选） |
| category | string | 否 | - | 岗位分类（如：研发、产品、设计、运营） |
| description | string | 否 | - | 岗位描述 |
| requirements | string | 否 | - | 岗位要求 |
| location | string | 否 | - | 工作地点 |
| status | string | 否 | 已发布 | 状态：已发布、草稿 |
| publishTime | string | 否 | 当前时间 | 发布时间（ISO格式） |

**请求示例**
```json
{
  "name": "Go开发工程师",
  "code": "GO-DEV-001",
  "category": "研发",
  "description": "负责Go后端开发",
  "requirements": "熟悉Go语言和Gin框架",
  "location": "北京",
  "status": "已发布"
}
```

---

#### 4. 更新岗位

**接口信息**
- **请求方式：** PUT
- **请求路径：** `/admin/position`
- **接口说明：** 更新岗位信息

**请求参数（Body）**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 岗位ID |
| name | string | 否 | 岗位名称 |
| code | string | 否 | 岗位编码 |
| category | string | 否 | 岗位分类 |
| description | string | 否 | 岗位描述 |
| requirements | string | 否 | 岗位要求 |
| location | string | 否 | 工作地点 |
| status | string | 否 | 状态：已发布、草稿 |
| publishTime | string | 否 | 发布时间 |

---

#### 5. 删除岗位

**接口信息**
- **请求方式：** DELETE
- **请求路径：** `/admin/position/{id}`
- **接口说明：** 物理删除岗位

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 岗位ID |

---

#### 6. 修改岗位状态

**接口信息**
- **请求方式：** PUT
- **请求路径：** `/admin/position/{id}/status`
- **接口说明：** 修改岗位状态

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 岗位ID |

**请求参数（Query）**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| status | string | 是 | 状态：已发布、草稿 |

---

### 四、文章/推荐管理（article表）

**数据库表结构：**
- 主键：`id` bigint
- 字段：title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, create_time, update_time, deleted
- 注意：需要客户端添加 `category` 字段（用于文章分类）

#### 1. 获取文章列表

**接口信息**
- **请求方式：** GET
- **请求路径：** `/admin/article/list`
- **接口说明：** 分页查询文章/推荐列表

**请求参数（Query）**

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| pageNum | int | 否 | 1 | 页码 |
| pageSize | int | 否 | 10 | 每页数量 |
| keyword | string | 否 | - | 搜索关键词（标题） |
| type | int | 否 | - | 类型：1-课程，2-文章 |
| status | int | 否 | - | 状态：0-禁用，1-启用 |

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "records": [
      {
        "id": 1,
        "title": "Java面试指南",
        "category": 0,
        "type": 2,
        "coverUrl": "https://example.com/cover.jpg",
        "linkUrl": "https://example.com/article",
        "description": "完整的Java面试准备指南",
        "author": "John Doe",
        "source": "Tech Blog",
        "sort": 0,
        "viewCount": 100,
        "status": 1,
        "publishTime": "2024-01-01T12:00:00",
        "createTime": "2024-01-01T12:00:00"
      }
    ],
    "total": 50,
    "size": 10,
    "current": 1,
    "pages": 5
  }
}
```

---

#### 2. 获取文章详情

**接口信息**
- **请求方式：** GET
- **请求路径：** `/admin/article/{id}`
- **接口说明：** 根据ID查询文章详情

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 文章ID |

---

#### 3. 新增文章

**接口信息**
- **请求方式：** POST
- **请求路径：** `/admin/article`
- **接口说明：** 新增文章/推荐

**请求参数（Body）**

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| title | string | 是 | - | 标题 |
| category | int | 否 | 0 | 分类：0-Java后端, 1-Web前端, 2-Python, 3-Go后端, 4-通用 |
| type | int | 是 | - | 类型：1-课程，2-文章 |
| coverUrl | string | 否 | - | 封面图片URL |
| linkUrl | string | 是 | - | 链接地址 |
| description | string | 否 | - | 描述/简介 |
| author | string | 否 | - | 作者 |
| source | string | 否 | - | 来源 |
| sort | int | 否 | 0 | 排序号 |
| status | int | 否 | 1 | 状态：0-禁用，1-启用 |
| publishTime | string | 否 | 当前时间 | 发布时间 |

---

#### 4. 更新文章

**接口信息**
- **请求方式：** PUT
- **请求路径：** `/admin/article`
- **接口说明：** 更新文章信息

---

#### 5. 删除文章

**接口信息**
- **请求方式：** DELETE
- **请求路径：** `/admin/article/{id}`
- **接口说明：** 物理删除文章

---

#### 6. 修改文章状态

**接口信息**
- **请求方式：** PUT
- **请求路径：** `/admin/article/{id}/status`
- **接口说明：** 启用/禁用文章

**请求参数（Query）**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| status | int | 是 | 状态：0-禁用，1-启用 |

---

#### 7. 获取文章分类列表

**接口信息**
- **请求方式：** GET
- **请求路径：** `/admin/article/categories`
- **接口说明：** 获取文章分类枚举列表

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": [
    {"code": 0, "desc": "Java后端"},
    {"code": 1, "desc": "Web前端"},
    {"code": 2, "desc": "Python"},
    {"code": 3, "desc": "Go后端"},
    {"code": 4, "desc": "通用"}
  ]
}
```

---

### 五、面试记录管理（interview_session表）

**数据库表结构：**
- 主键：`session_id` bigint
- 字段：user_id, position_id, resume_id, interview_mode, interview_status, start_time, end_time, interview_duration, total_score, interview_evaluation, has_report, create_time, update_time

#### 1. 获取面试记录列表

**接口信息**
- **请求方式：** GET
- **请求路径：** `/admin/interview-record/list`
- **接口说明：** 分页查询面试记录列表

**请求参数（Query）**

| 参数名 | 类型 | 必填 | 默认值 | 说明 |
|--------|------|------|--------|------|
| pageNum | int | 否 | 1 | 页码 |
| pageSize | int | 否 | 10 | 每页数量 |
| userId | long | 否 | - | 用户ID筛选 |
| positionId | long | 否 | - | 岗位ID筛选 |

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "records": [
      {
        "id": 1,
        "userId": 1,
        "positionId": 1,
        "resumeId": 1,
        "interviewMode": "text",
        "interviewStatus": 2,
        "startTime": "2024-01-01T10:00:00",
        "endTime": "2024-01-01T10:30:00",
        "interviewDuration": 1800,
        "totalScore": 85.50,
        "interviewEvaluation": "良好",
        "hasReport": 1,
        "createTime": "2024-01-01T10:00:00"
      }
    ],
    "total": 100,
    "size": 10,
    "current": 1,
    "pages": 10
  }
}
```

**字段说明：**

| 字段名 | 类型 | 说明 |
|--------|------|------|
| interviewMode | string | 面试模式：text-文本问答, voice-语音问答 |
| interviewStatus | int | 面试状态：0-未开始, 1-进行中, 2-已完成, 3-已中断 |
| interviewDuration | int | 面试总时长，单位：秒 |
| totalScore | decimal | 综合得分（满分100） |
| interviewEvaluation | string | 综合评价等级：优秀、良好、一般、需改进 |
| hasReport | int | 是否生成评估报告：0-否, 1-是 |

---

#### 2. 获取面试记录详情

**接口信息**
- **请求方式：** GET
- **请求路径：** `/admin/interview-record/{id}`
- **接口说明：** 根据ID查询面试记录详情

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 面试记录ID (session_id) |

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "id": 1,
    "userId": 1,
    "userName": "张三",
    "userAvatar": "https://example.com/avatar.jpg",
    "positionId": 1,
    "positionName": "Java开发工程师",
    "interviewTime": "2024-01-01T10:00:00",
    "score": 85.50,
    "startTime": "2024-01-01T10:00:00",
    "endTime": "2024-01-01T10:45:00",
    "duration": 45,
    "contentScore": 88.00,
    "expressionScore": 82.00,
    "dimensionScoreDetail": "{}",
    "interviewHighlights": "回答问题思路清晰",
    "interviewShortcomings": "部分技术细节不够深入",
    "improvementSuggestions": "建议加强算法练习",
    "excellentAnswerCase": "数据库优化问题回答优秀",
    "adminComment": null,
    "adminId": null,
    "adminCommentTime": null,
    "reportGenerateTime": "2024-01-01T10:50:00",
    "reportStatus": 1,
    "createTime": "2024-01-01T10:00:00"
  }
}
```

----

#### 3. 创建面试记录

**接口信息**
- **请求方式：** POST
- **请求路径：** `/admin/interview-record`
- **接口说明：** 手动录入面试记录

**请求参数（Body）**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| userId | long | 是 | 用户ID |
| positionId | long | 是 | 岗位ID |
| resumeId | long | 否 | 简历ID |
| interviewMode | string | 否 | 面试模式：text-文本, voice-语音 |
| interviewStatus | int | 否 | 状态：0-未开始, 1-进行中, 2-已完成, 3-已中断 |
| startTime | string | 否 | 开始时间（ISO格式）|
| endTime | string | 否 | 结束时间（ISO格式）|
| interviewDuration | int | 否 | 面试时长（秒）|
| totalScore | decimal | 否 | 综合得分 |
| interviewEvaluation | string | 否 | 评价等级 |

**请求示例**
```json
{
  "userId": 11,
  "positionId": 1,
  "interviewMode": "text",
  "interviewStatus": 2,
  "startTime": "2026-04-18T10:37:00",
  "endTime": "2026-04-18T11:22:00",
  "interviewDuration": 2700,
  "totalScore": 80.00,
  "interviewEvaluation": "良好"
}
```

----

#### 4. 更新面试记录

**接口信息**
- **请求方式：** PUT
- **请求路径：** `/admin/interview-record/update/{id}`
- **接口说明：** 更新面试记录信息

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 面试记录ID |

**请求参数（Body）**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| userId | long | 否 | 用户ID |
| positionId | long | 否 | 岗位ID |
| interviewMode | string | 否 | 面试模式 |
| interviewStatus | int | 否 | 面试状态 |
| startTime | string | 否 | 开始时间 |
| endTime | string | 否 | 结束时间 |
| interviewDuration | int | 否 | 面试时长（秒）|
| totalScore | decimal | 否 | 综合得分 |
| interviewEvaluation | string | 否 | 评价等级 |

**请求示例**
```json
{
  "userId": 11,
  "positionId": 2,
  "totalScore": 85.00,
  "interviewEvaluation": "优秀"
}
```

----

#### 5. 删除面试记录

**接口信息**
- **请求方式：** DELETE
- **请求路径：** `/admin/interview-record/{id}`
- **接口说明：** 删除单条面试记录

**路径参数**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| id | long | 是 | 面试记录ID |

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": null
}
```

----

#### 6. 批量删除面试记录

**接口信息**
- **请求方式：** DELETE
- **请求路径：** `/admin/interview-record/batch`
- **接口说明：** 批量删除面试记录

**请求参数（Body）**

| 参数名 | 类型 | 必填 | 说明 |
|--------|------|------|------|
| ids | array | 是 | 面试记录ID数组 |

**请求示例**
```json
[1, 2, 3]
```

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": null
}
```

----

### 六、数据统计

#### 1. 获取仪表盘统计数据

**接口信息**
- **请求方式：** GET
- **请求路径：** `/admin/dashboard/stats`
- **接口说明：** 获取仪表盘统计数据

**响应示例**
```json
{
  "code": 200,
  "message": "操作成功",
  "data": {
    "totalUsers": 1000,
    "activeUsers": 500,
    "totalPositions": 50,
    "totalQuestions": 0,
    "todayInterviews": 10,
    "totalInterviews": 100,
    "thisMonthNewUsers": 50,
    "recentUsers": [
      {
        "userId": 1,
        "username": "user1",
        "realName": "张三",
        "avatar": "",
        "phone": "",
        "email": "",
        "interviewCount": 0,
        "avgScore": 0,
        "status": 1,
        "createTime": "2024-01-01T12:00:00"
      }
    ]
  }
}
```

---

## 附录

### 数据库表对照

| 后台管理表 | 客户端数据库表 | 说明 |
|-----------|---------------|------|
| admin | admin | 管理员表 |
| sys_user | sys_user | 系统用户表（管理员+学生） |
| job_position | job_position | 岗位表 |
| article | article | 课程/文章推荐表 |
| interview_record | interview_session | 面试会话表 |

### 状态字段说明

#### 用户状态（sys_user表）
| 值 | 说明 |
|----|------|
| 1 | 正常 |
| 0 | 禁用 |

#### 岗位状态（job_position表）
| 值 | 说明 |
|----|------|
| 已发布 | 岗位已发布 |
| 草稿 | 草稿状态 |

#### 文章状态（article表）
| 值 | 说明 |
|----|------|
| 1 | 启用 |
| 0 | 禁用 |

#### 文章类型（article表）
| 值 | 说明 |
|----|------|
| 1 | 课程 |
| 2 | 文章 |

#### 文章分类（article表）
| 值 | 说明 |
|----|------|
| 0 | Java后端 |
| 1 | Web前端 |
| 2 | Python |
| 3 | Go后端 |
| 4 | 通用 |

#### 面试状态（interview_session表）
| 值 | 说明 |
|----|------|
| 0 | 未开始 |
| 1 | 进行中 |
| 2 | 已完成 |
| 3 | 已中断 |

#### 面试模式（interview_session表）
| 值 | 说明 |
|----|------|
| text | 文本问答 |
| voice | 语音问答 |

### 时间格式

所有时间字段统一使用 ISO 8601 格式：
- **格式：** `yyyy-MM-dd'T'HH:mm:ss`
- **示例：** `2024-01-01T12:00:00`

---

## 更新日志

### 2026-04-17
- 适配客户端后端数据库表结构
- 更新用户表为 sys_user，主键改为 user_id
- 更新面试记录表为 interview_session，主键改为 session_id
- 岗位表字段：name, code, category, description, requirements, location, status, publish_time, create_time, update_time, deleted（无 salaryRange、sort 字段）
- 文章表字段：title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, create_time, update_time, deleted（需客户端添加 category 字段）
- 统一时间格式为 ISO 8601
