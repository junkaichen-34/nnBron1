-- =====================================================
-- 面试么AI模拟面试系统 - 数据库建表语句
-- 数据库名: test-mianshi
-- 字符集: utf8mb4
-- 生成时间: 2026-04-17
-- =====================================================

-- 1. 管理员表
CREATE TABLE IF NOT EXISTS `admin` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '管理员ID',
  `username` varchar(50) NOT NULL COMMENT '用户名（登录账号）',
  `password` varchar(255) NOT NULL COMMENT '密码（BCrypt加密）',
  `real_name` varchar(50) DEFAULT NULL COMMENT '真实姓名',
  `avatar` varchar(255) DEFAULT NULL COMMENT '头像URL',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `status` varchar(20) DEFAULT '已发布' COMMENT '状态：已发布、草稿',
  `last_login_ip` varchar(50) DEFAULT NULL COMMENT '最后登录IP',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint DEFAULT '0' COMMENT '删除标记：0-未删除，1-已删除',
  `last_login_id` varchar(64) DEFAULT NULL COMMENT '最后登录设备ID',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_username` (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='管理员表';

-- 2. 课程/文章推荐表
CREATE TABLE IF NOT EXISTS `article` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(200) NOT NULL COMMENT '标题',
  `type` tinyint NOT NULL COMMENT '类型：1-课程，2-文章',
  `cover_url` varchar(500) DEFAULT NULL COMMENT '封面图片URL',
  `link_url` varchar(500) NOT NULL COMMENT '链接地址',
  `description` text COMMENT '描述/简介',
  `author` varchar(100) DEFAULT NULL COMMENT '作者',
  `source` varchar(100) DEFAULT NULL COMMENT '来源',
  `sort` int DEFAULT '0' COMMENT '排序（数字越小越靠前）',
  `view_count` int DEFAULT '0' COMMENT '浏览次数',
  `status` tinyint DEFAULT '1' COMMENT '状态：0-禁用，1-启用',
  `publish_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint DEFAULT '0' COMMENT '删除标记：0-未删除，1-已删除',
  `category` tinyint DEFAULT '4' COMMENT '分类：0-Java后端, 1-Web前端, 2-Python, 3-Go后端, 4-通用',
  PRIMARY KEY (`id`),
  KEY `idx_type` (`type`),
  KEY `idx_status` (`status`),
  KEY `idx_sort` (`sort`),
  KEY `idx_publish_time` (`publish_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='课程/文章推荐表';

-- 3. 系统用户表（管理员+学生）
CREATE TABLE IF NOT EXISTS `sys_user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT COMMENT '用户唯一ID',
  `username` varchar(50) NOT NULL COMMENT '登录账号',
  `password` varchar(100) NOT NULL COMMENT '加密存储的登录密码',
  `real_name` varchar(50) DEFAULT NULL COMMENT '用户真实姓名',
  `avatar` varchar(255) DEFAULT NULL COMMENT '用户头像URL地址',
  `role_type` tinyint NOT NULL COMMENT '角色类型：1-系统管理员 2-学生用户',
  `phone` varchar(20) DEFAULT NULL COMMENT '手机号',
  `deleted` tinyint DEFAULT '0' COMMENT '删除标记：0-未删除，1-已删除',
  `email` varchar(100) DEFAULT NULL COMMENT '邮箱',
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '账号状态：0-禁用 1-正常',
  `register_time` datetime DEFAULT NULL COMMENT '注册时间',
  `last_login_time` datetime DEFAULT NULL COMMENT '最后登录时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记录创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '记录更新时间',
  `remark` varchar(255) DEFAULT NULL COMMENT '备注信息',
  `interview_count` int DEFAULT '0' COMMENT '面试次数',
  `avg_score` decimal(5,2) DEFAULT '0.00' COMMENT '平均分数',
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `uk_username` (`username`),
  KEY `idx_role_type` (`role_type`),
  KEY `idx_status` (`status`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='系统用户表';

-- 4. 用户简历表
CREATE TABLE IF NOT EXISTS `user_resume` (
  `resume_id` bigint NOT NULL AUTO_INCREMENT COMMENT '简历唯一ID',
  `user_id` bigint NOT NULL COMMENT '所属用户ID',
  `resume_name` varchar(255) NOT NULL COMMENT '简历文件名称',
  `resume_file_url` varchar(255) NOT NULL COMMENT '简历文件存储地址',
  `resume_content` longtext COMMENT '简历解析后的纯文本内容',
  `upload_time` datetime NOT NULL COMMENT '上传时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_default` tinyint NOT NULL DEFAULT '0' COMMENT '是否默认简历：0-否 1-是',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`resume_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_is_default` (`is_default`),
  KEY `idx_is_deleted` (`is_deleted`),
  CONSTRAINT `fk_resume_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户简历表';

-- 5. 岗位表
CREATE TABLE IF NOT EXISTS `job_position` (
  `id` bigint NOT NULL AUTO_INCREMENT COMMENT '岗位ID',
  `name` varchar(100) NOT NULL COMMENT '岗位名称',
  `code` varchar(50) DEFAULT NULL COMMENT '岗位编码（唯一标识）',
  `category` varchar(50) NOT NULL COMMENT '岗位分类（如：研发、产品、设计、运营）',
  `description` text COMMENT '岗位描述',
  `requirements` text COMMENT '岗位要求',
  `location` varchar(100) DEFAULT NULL COMMENT '工作地点',
  `status` varchar(20) DEFAULT '已发布' COMMENT '状态：已发布、草稿',
  `publish_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '发布时间',
  `create_time` datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `deleted` tinyint DEFAULT '0' COMMENT '删除标记：0-未删除，1-已删除',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uk_code` (`code`),
  KEY `idx_category` (`category`),
  KEY `idx_status` (`status`),
  KEY `idx_publish_time` (`publish_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci COMMENT='岗位表';

-- 6. 面试会话主表
CREATE TABLE IF NOT EXISTS `interview_session` (
  `session_id` bigint NOT NULL AUTO_INCREMENT COMMENT '面试会话唯一ID',
  `user_id` bigint NOT NULL COMMENT '面试用户ID',
  `position_id` bigint NOT NULL COMMENT '面试岗位ID',
  `resume_id` bigint DEFAULT NULL COMMENT '本次面试使用的简历ID',
  `interview_mode` varchar(50) NOT NULL COMMENT '面试模式：text-文本问答, voice-语音问答',
  `interview_status` tinyint NOT NULL DEFAULT '0' COMMENT '面试状态：0-未开始 1-进行中 2-已完成 3-已中断',
  `start_time` datetime DEFAULT NULL COMMENT '面试开始时间',
  `end_time` datetime DEFAULT NULL COMMENT '面试结束时间',
  `interview_duration` int DEFAULT NULL COMMENT '面试总时长，单位：秒',
  `total_score` decimal(5,2) DEFAULT NULL COMMENT '本次面试综合得分（满分100）',
  `interview_evaluation` varchar(50) DEFAULT NULL COMMENT '综合评价等级：优秀、良好、一般、需改进',
  `has_report` tinyint NOT NULL DEFAULT '0' COMMENT '是否生成评估报告：0-否 1-是',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  PRIMARY KEY (`session_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_position_id` (`position_id`),
  KEY `idx_interview_status` (`interview_status`),
  KEY `idx_create_time` (`create_time`),
  CONSTRAINT `fk_session_resume` FOREIGN KEY (`resume_id`) REFERENCES `user_resume` (`resume_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_session_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='面试会话主表';

-- 7. 面试对话详情表
CREATE TABLE IF NOT EXISTS `interview_dialogue` (
  `dialogue_id` bigint NOT NULL AUTO_INCREMENT COMMENT '对话记录唯一ID',
  `session_id` bigint NOT NULL COMMENT '所属面试会话ID',
  `dialogue_round` int NOT NULL COMMENT '对话轮次（第1轮、第2轮...）',
  `question_id` bigint DEFAULT '0' COMMENT '关联题库题目ID，AI生成的追问题可置为0',
  `question_content` text NOT NULL COMMENT 'AI面试官提出的问题内容',
  `question_type` varchar(50) NOT NULL COMMENT '问题类型：自我介绍、技术深度、岗位匹配等',
  `user_answer_content` longtext COMMENT '用户回答的文本内容',
  `user_answer_audio_url` varchar(255) DEFAULT NULL COMMENT '用户回答的语音文件地址',
  `answer_duration` int DEFAULT NULL COMMENT '用户回答时长，单位：秒',
  `ai_feedback` text COMMENT 'AI针对本次回答的实时反馈',
  `answer_score` decimal(5,2) DEFAULT NULL COMMENT '本道题得分（满分100）',
  `score_dimension` json DEFAULT NULL COMMENT '本题单维度得分，JSON格式存储',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '记录创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '记录更新时间',
  PRIMARY KEY (`dialogue_id`),
  KEY `idx_session_id` (`session_id`),
  KEY `idx_dialogue_round` (`dialogue_round`),
  KEY `idx_question_id` (`question_id`),
  CONSTRAINT `fk_dialogue_session` FOREIGN KEY (`session_id`) REFERENCES `interview_session` (`session_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='面试对话详情表';

-- 8. 面试评估报告表
CREATE TABLE IF NOT EXISTS `interview_report` (
  `report_id` bigint NOT NULL AUTO_INCREMENT COMMENT '报告唯一ID',
  `session_id` bigint NOT NULL COMMENT '关联面试会话ID（一对一）',
  `user_id` bigint NOT NULL COMMENT '所属用户ID',
  `position_id` bigint NOT NULL COMMENT '所属岗位ID',
  `total_score` decimal(5,2) NOT NULL COMMENT '综合得分',
  `content_score` decimal(5,2) NOT NULL COMMENT '内容维度综合得分',
  `expression_score` decimal(5,2) NOT NULL COMMENT '表达维度综合得分',
  `dimension_score_detail` json NOT NULL COMMENT '全维度详细得分，JSON格式存储',
  `interview_highlights` longtext NOT NULL COMMENT '本次面试亮点分析',
  `interview_shortcomings` longtext NOT NULL COMMENT '本次面试不足分析',
  `improvement_suggestions` longtext NOT NULL COMMENT '针对性改进建议',
  `excellent_answer_case` longtext COMMENT '优秀回答范例参考',
  `admin_comment` text COMMENT '后台管理员输入的评语',
  `admin_id` bigint DEFAULT NULL COMMENT '评语管理员ID',
  `admin_comment_time` datetime DEFAULT NULL COMMENT '管理员评语时间',
  `report_generate_time` datetime NOT NULL COMMENT '报告生成时间',
  `report_status` tinyint NOT NULL DEFAULT '0' COMMENT '报告状态：0-生成中 1-已生成 2-生成失败',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`report_id`),
  UNIQUE KEY `uk_session_id` (`session_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_position_id` (`position_id`),
  KEY `idx_report_status` (`report_status`),
  KEY `idx_is_deleted` (`is_deleted`),
  CONSTRAINT `fk_report_session` FOREIGN KEY (`session_id`) REFERENCES `interview_session` (`session_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_report_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='面试评估报告表';

-- 9. 用户能力画像表
CREATE TABLE IF NOT EXISTS `user_ability_profile` (
  `profile_id` bigint NOT NULL AUTO_INCREMENT COMMENT '画像唯一ID',
  `user_id` bigint NOT NULL COMMENT '所属用户ID',
  `position_id` bigint NOT NULL COMMENT '对应岗位ID',
  `ability_dimension_detail` json NOT NULL COMMENT '能力维度详情，JSON格式存储',
  `total_ability_score` decimal(5,2) NOT NULL COMMENT '综合能力得分',
  `interview_count` int NOT NULL DEFAULT '0' COMMENT '累计面试次数',
  `average_score` decimal(5,2) DEFAULT NULL COMMENT '历史面试平均分',
  `last_interview_time` datetime DEFAULT NULL COMMENT '最近一次面试时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '画像更新时间',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`profile_id`),
  UNIQUE KEY `uk_user_position` (`user_id`,`position_id`),
  KEY `idx_total_ability_score` (`total_ability_score`),
  CONSTRAINT `fk_profile_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户能力画像表';

-- 10. 用户成长数据表
CREATE TABLE IF NOT EXISTS `user_interview_growth` (
  `growth_id` bigint NOT NULL AUTO_INCREMENT COMMENT '成长记录唯一ID',
  `user_id` bigint NOT NULL COMMENT '所属用户ID',
  `position_id` bigint NOT NULL COMMENT '对应岗位ID',
  `stat_date` date NOT NULL COMMENT '统计日期',
  `average_score` decimal(5,2) NOT NULL COMMENT '当日面试平均分',
  `dimension_avg_score` json DEFAULT NULL COMMENT '当日各维度平均分，JSON格式存储',
  `interview_count` int NOT NULL DEFAULT '0' COMMENT '当日面试次数',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  PRIMARY KEY (`growth_id`),
  KEY `idx_user_position` (`user_id`,`position_id`),
  KEY `idx_stat_date` (`stat_date`),
  CONSTRAINT `fk_growth_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户成长数据表';

-- 11. 用户学习计划表
CREATE TABLE IF NOT EXISTS `user_learning_plan` (
  `plan_id` bigint NOT NULL AUTO_INCREMENT COMMENT '计划唯一ID',
  `user_id` bigint NOT NULL COMMENT '所属用户ID',
  `related_report_id` bigint DEFAULT NULL COMMENT '关联的面试报告ID',
  `plan_title` varchar(255) NOT NULL COMMENT '计划标题',
  `plan_content` longtext NOT NULL COMMENT '计划详细内容',
  `start_date` date DEFAULT NULL COMMENT '计划开始日期',
  `end_date` date DEFAULT NULL COMMENT '计划结束日期',
  `plan_status` tinyint NOT NULL DEFAULT '0' COMMENT '计划状态：0-未开始 1-进行中 2-已完成',
  `resource_ids` text COMMENT '关联的学习资源ID，逗号分隔',
  `create_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间',
  `update_time` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间',
  `is_deleted` tinyint NOT NULL DEFAULT '0' COMMENT '逻辑删除：0-未删除 1-已删除',
  PRIMARY KEY (`plan_id`),
  KEY `idx_user_id` (`user_id`),
  KEY `idx_related_report_id` (`related_report_id`),
  KEY `idx_plan_status` (`plan_status`),
  KEY `idx_is_deleted` (`is_deleted`),
  CONSTRAINT `fk_plan_report` FOREIGN KEY (`related_report_id`) REFERENCES `interview_report` (`report_id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `fk_plan_user` FOREIGN KEY (`user_id`) REFERENCES `sys_user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户学习计划表';
