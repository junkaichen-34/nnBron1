-- 插入10条面试记录到interview_session表
-- 关联新插入的用户（user_id 16-31）和已有的岗位（position_id 1-4）

INSERT INTO interview_session (user_id, position_id, resume_id, interview_mode, interview_status, start_time, end_time, interview_duration, total_score, interview_evaluation, has_report, is_deleted, create_time) VALUES
(16, 1, NULL, 'text', 2, DATE_SUB(NOW(), INTERVAL 2 DAY), DATE_SUB(NOW(), INTERVAL 2 DAY) + INTERVAL 45 MINUTE, 2700, 88.50, '优秀', 1, 0, DATE_SUB(NOW(), INTERVAL 2 DAY));

INSERT INTO interview_session (user_id, position_id, resume_id, interview_mode, interview_status, start_time, end_time, interview_duration, total_score, interview_evaluation, has_report, is_deleted, create_time) VALUES
(17, 2, NULL, 'text', 2, DATE_SUB(NOW(), INTERVAL 3 DAY), DATE_SUB(NOW(), INTERVAL 3 DAY) + INTERVAL 38 MINUTE, 2280, 82.00, '良好', 1, 0, DATE_SUB(NOW(), INTERVAL 3 DAY));

INSERT INTO interview_session (user_id, position_id, resume_id, interview_mode, interview_status, start_time, end_time, interview_duration, total_score, interview_evaluation, has_report, is_deleted, create_time) VALUES
(18, 3, NULL, 'voice', 2, DATE_SUB(NOW(), INTERVAL 5 DAY), DATE_SUB(NOW(), INTERVAL 5 DAY) + INTERVAL 52 MINUTE, 3120, 91.00, '优秀', 1, 0, DATE_SUB(NOW(), INTERVAL 5 DAY));

INSERT INTO interview_session (user_id, position_id, resume_id, interview_mode, interview_status, start_time, end_time, interview_duration, total_score, interview_evaluation, has_report, is_deleted, create_time) VALUES
(19, 1, NULL, 'text', 2, DATE_SUB(NOW(), INTERVAL 1 DAY), DATE_SUB(NOW(), INTERVAL 1 DAY) + INTERVAL 41 MINUTE, 2460, 76.50, '良好', 1, 0, DATE_SUB(NOW(), INTERVAL 1 DAY));

INSERT INTO interview_session (user_id, position_id, resume_id, interview_mode, interview_status, start_time, end_time, interview_duration, total_score, interview_evaluation, has_report, is_deleted, create_time) VALUES
(20, 4, NULL, 'text', 2, DATE_SUB(NOW(), INTERVAL 4 DAY), DATE_SUB(NOW(), INTERVAL 4 DAY) + INTERVAL 35 MINUTE, 2100, 85.00, '优秀', 1, 0, DATE_SUB(NOW(), INTERVAL 4 DAY));

INSERT INTO interview_session (user_id, position_id, resume_id, interview_mode, interview_status, start_time, end_time, interview_duration, total_score, interview_evaluation, has_report, is_deleted, create_time) VALUES
(21, 2, NULL, 'voice', 2, DATE_SUB(NOW(), INTERVAL 6 DAY), DATE_SUB(NOW(), INTERVAL 6 DAY) + INTERVAL 48 MINUTE, 2880, 79.00, '良好', 1, 0, DATE_SUB(NOW(), INTERVAL 6 DAY));

INSERT INTO interview_session (user_id, position_id, resume_id, interview_mode, interview_status, start_time, end_time, interview_duration, total_score, interview_evaluation, has_report, is_deleted, create_time) VALUES
(22, 3, NULL, 'text', 2, DATE_SUB(NOW(), INTERVAL 2 DAY), DATE_SUB(NOW(), INTERVAL 2 DAY) + INTERVAL 44 MINUTE, 2640, 93.50, '优秀', 1, 0, DATE_SUB(NOW(), INTERVAL 2 DAY));

INSERT INTO interview_session (user_id, position_id, resume_id, interview_mode, interview_status, start_time, end_time, interview_duration, total_score, interview_evaluation, has_report, is_deleted, create_time) VALUES
(23, 1, NULL, 'text', 2, DATE_SUB(NOW(), INTERVAL 7 DAY), DATE_SUB(NOW(), INTERVAL 7 DAY) + INTERVAL 39 MINUTE, 2340, 74.00, '一般', 1, 0, DATE_SUB(NOW(), INTERVAL 7 DAY));

INSERT INTO interview_session (user_id, position_id, resume_id, interview_mode, interview_status, start_time, end_time, interview_duration, total_score, interview_evaluation, has_report, is_deleted, create_time) VALUES
(24, 4, NULL, 'voice', 2, DATE_SUB(NOW(), INTERVAL 1 DAY), DATE_SUB(NOW(), INTERVAL 1 DAY) + INTERVAL 50 MINUTE, 3000, 87.00, '优秀', 1, 0, DATE_SUB(NOW(), INTERVAL 1 DAY));

INSERT INTO interview_session (user_id, position_id, resume_id, interview_mode, interview_status, start_time, end_time, interview_duration, total_score, interview_evaluation, has_report, is_deleted, create_time) VALUES
(25, 2, NULL, 'text', 2, DATE_SUB(NOW(), INTERVAL 4 DAY), DATE_SUB(NOW(), INTERVAL 4 DAY) + INTERVAL 42 MINUTE, 2520, 81.50, '良好', 1, 0, DATE_SUB(NOW(), INTERVAL 4 DAY));
