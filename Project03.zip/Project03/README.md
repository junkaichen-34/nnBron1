# AI模拟面试平台 - 后台管理系统

基于 Spring Boot 3 的 AI 模拟面试平台后台管理系统，提供 RESTful API，支持管理员对用户、岗位、面试记录、课程文章等数据进行管理。

## 技术栈

| 技术 | 版本 | 说明 |
|------|------|------|
| Java | 17 | 运行环境 |
| Spring Boot | 3.1.5 | 核心框架 |
| MyBatis-Plus | 3.5.5 | ORM 框架 |
| MySQL | 8.0 | 关系型数据库 |
| Redis | — | 缓存 |
| JWT (jjwt) | 0.12.3 | 身份认证 |
| Knife4j | 4.4.0 | API 文档（增强 Swagger UI） |
| SpringDoc OpenAPI | 2.2.0 | OpenAPI 3.0 规范 |
| Druid | 1.2.20 | 数据库连接池 |
| Hutool | 5.8.23 | Java 工具库 |
| Spring Security Crypto | — | 密码加密（BCrypt） |
| Maven | 3.x | 构建工具 |

## 功能模块

| 序号 | 模块 | 功能描述 |
|:----:|------|----------|
| 1 | 仪表盘 | 平台运营数据概览（用户数、岗位数、面试数、新增统计、最新用户） |
| 2 | 岗位管理 | 岗位 CRUD、状态管理（已发布/草稿）、分类筛选 |
| 3 | 知识库（课程/文章） | 课程和文章推荐管理、分类、启用/禁用 |
| 4 | 面试管理 | 面试记录查看、筛选、批量删除 |
| 5 | 面试报告 | 面试详情查看、AI 评价、管理员评语 |
| 6 | 用户管理 | 用户列表、详情、账号禁用/启用 |
| 7 | 管理员认证 | 管理员注册/登录、JWT Token 鉴权、密码修改 |
| 8 | 客户端 API | 为前端客户端提供岗位、文章、面试记录查询接口 |

## 项目结构

```
Project03/
├── backend/                          # Spring Boot 后端项目
│   ├── pom.xml                       # Maven 配置
│   ├── API文档.md                    # 后台管理 API 文档
│   ├── 客户端前端API文档.md          # 客户端前端 API 文档
│   └── src/main/
│       ├── java/com/interview/admin/
│       │   ├── InterviewAdminApplication.java   # 启动类
│       │   ├── common/               # 通用组件（异常、响应封装）
│       │   ├── config/               # 配置类（MyBatis-Plus、CORS、Knife4j、Jackson）
│       │   ├── controller/           # 控制器层
│       │   │   ├── AdminAuthController.java           # 管理员认证
│       │   │   ├── UserController.java                # 用户管理
│       │   │   ├── JobPositionController.java         # 岗位管理
│       │   │   ├── ArticleController.java             # 文章管理
│       │   │   ├── InterviewRecordController.java     # 面试记录管理
│       │   │   ├── DashboardController.java           # 仪表盘统计
│       │   │   ├── ClientArticleController.java       # 客户端-文章
│       │   │   ├── ClientJobPositionController.java   # 客户端-岗位
│       │   │   └── ClientInterviewRecordController.java # 客户端-面试记录
│       │   ├── dto/                  # 数据传输对象
│       │   ├── entity/               # 数据库实体
│       │   ├── enums/                # 枚举类
│       │   ├── mapper/               # MyBatis-Plus Mapper
│       │   ├── security/             # JWT 拦截器 & 安全上下文
│       │   ├── service/              # 服务接口 & 实现
│       │   ├── util/                 # 工具类（JWT）
│       │   └── vo/                   # 视图对象
│       └── resources/
│           ├── application.example.yml  # 配置文件模板
│           └── db/
│               └── schema_new.sql       # 数据库建表脚本（备用）
├── test-mianshi-schema.sql          # 完整数据库建表语句（11张表）
├── insert_users.sql                  # 用户示例数据
├── insert_articles.sql               # 文章示例数据
├── insert_interview_sessions.sql     # 面试记录示例数据
└── 项目需求文档.md                    # 项目需求文档
```

## 数据库设计

共 11 张表，数据库名为 `test-mianshi`：

| 表名 | 说明 |
|------|------|
| `admin` | 管理员表 |
| `sys_user` | 系统用户表（管理员 + 学生） |
| `user_resume` | 用户简历表 |
| `job_position` | 岗位表 |
| `article` | 课程/文章推荐表 |
| `interview_session` | 面试会话主表 |
| `interview_dialogue` | 面试对话详情表 |
| `interview_report` | 面试评估报告表 |
| `user_ability_profile` | 用户能力画像表 |
| `user_interview_growth` | 用户成长数据表 |
| `user_learning_plan` | 用户学习计划表 |

## 快速开始

### 环境要求

- JDK 17+
- Maven 3.x
- MySQL 8.0+
- Redis（可选）

### 1. 创建数据库

执行 `test-mianshi-schema.sql` 建表：

```bash
mysql -u root -p < test-mianshi-schema.sql
```

### 2. 导入示例数据（可选）

```bash
mysql -u root -p test-mianshi < insert_users.sql
mysql -u root -p test-mianshi < insert_articles.sql
mysql -u root -p test-mianshi < insert_interview_sessions.sql
```

### 3. 配置数据库连接

复制配置模板并修改为你的数据库信息：

```bash
cp backend/src/main/resources/application.example.yml backend/src/main/resources/application.yml
```

编辑 `application.yml`，修改以下配置：

- `spring.datasource.url` — 数据库连接地址
- `spring.datasource.username` / `password` — 数据库账号密码
- `spring.data.redis.*` — Redis 连接信息
- `jwt.secret` — JWT 签名密钥

### 4. 启动项目

```bash
cd backend
mvn spring-boot:run
```

启动成功后访问：

- **Knife4j API 文档**：http://localhost:8080/api/doc.html
- **Swagger UI**：http://localhost:8080/api/swagger-ui/index.html

### 5. 测试登录

使用管理员账号登录：

```json
POST /api/admin/auth/login
{
  "username": "admin",
  "password": "123456"
}
```

## API 概览

### 后台管理接口（需认证）

| 方法 | 路径 | 说明 |
|------|------|------|
| POST | `/admin/auth/login` | 管理员登录 |
| POST | `/admin/auth/register` | 管理员注册 |
| GET | `/admin/auth/info` | 获取当前管理员信息 |
| PUT | `/admin/auth/password` | 修改密码 |
| GET | `/admin/dashboard/stats` | 仪表盘统计数据 |
| GET | `/admin/user/list` | 用户列表（分页） |
| GET | `/admin/user/{id}` | 用户详情 |
| PUT | `/admin/user/{id}/status` | 启用/禁用用户 |
| GET | `/admin/position/list` | 岗位列表（分页） |
| POST | `/admin/position` | 新增岗位 |
| PUT | `/admin/position` | 更新岗位 |
| DELETE | `/admin/position/{id}` | 删除岗位 |
| GET | `/admin/article/list` | 文章列表（分页） |
| POST | `/admin/article` | 新增文章 |
| PUT | `/admin/article` | 更新文章 |
| DELETE | `/admin/article/{id}` | 删除文章 |
| GET | `/admin/interview-record/list` | 面试记录列表 |
| GET | `/admin/interview-record/{id}` | 面试记录详情 |
| DELETE | `/admin/interview-record/batch` | 批量删除面试记录 |

### 客户端接口（无需认证）

| 方法 | 路径 | 说明 |
|------|------|------|
| GET | `/client/article/list` | 课程/文章列表 |
| GET | `/client/article/{id}` | 课程/文章详情 |
| GET | `/client/position/list` | 岗位列表 |
| GET | `/client/position/{id}` | 岗位详情 |
| GET | `/client/interview-record/list` | 面试记录列表 |
| GET | `/client/interview-record/{id}` | 面试记录详情 |

完整 API 文档请查看：
- 后台接口：[backend/API文档.md](backend/API文档.md)
- 客户端接口：[backend/客户端前端API文档.md](backend/客户端前端API文档.md)

## 认证机制

采用 JWT Bearer Token 认证：

1. 调用 `/admin/auth/login` 获取 `accessToken`
2. 后续请求在 Header 中添加：`Authorization: Bearer {accessToken}`
3. Token 默认有效期 24 小时（可在 `application.yml` 中配置 `jwt.expiration`）

## License

Apache 2.0
