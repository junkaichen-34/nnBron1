-- 插入前端相关文章
INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('HTML5 新特性详解', 2, 'https://example.com/html5.jpg', 'https://developer.mozilla.org/Web/HTML', 'HTML5 引入了许多新特性，包括语义化标签、Canvas绘图、本地存储、WebSocket等，让Web开发更加强大和便捷。', '陈明远', 'MDN', 1, 1200, 1, NOW(), 1);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('CSS3 动画与过渡效果实战', 2, 'https://example.com/css3.jpg', 'https://css-tricks.com', '深入学习CSS3的transition、animation属性，掌握现代网页动画制作技巧，提升用户体验。', '林晓峰', 'CSS-Tricks', 2, 980, 1, NOW(), 1);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('JavaScript ES6 核心特性', 2, 'https://example.com/js.jpg', 'https://es6.ruanyifeng.com', '全面讲解ES6及后续版本的新特性：箭头函数、解构赋值、Promise、async/await、模块化等。', '阮一峰', '阮一峰博客', 3, 1500, 1, NOW(), 1);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('Vue3 组合式API入门指南', 2, 'https://example.com/vue3.jpg', 'https://vuejs.org', 'Vue3带来的Composition API改变了组件编写方式，本文详细介绍setup函数、响应式系统、生命周期钩子等核心概念。', '尤雨溪', 'Vue官方', 4, 2100, 1, NOW(), 1);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('React Hooks 深度解析', 2, 'https://example.com/react.jpg', 'https://react.dev', '深入理解useState、useEffect、useContext等常用Hooks，以及自定义Hooks的最佳实践。', 'Dan Abramov', 'React官方', 5, 1800, 1, NOW(), 1);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('前端性能优化最佳实践', 2, 'https://example.com/performance.jpg', 'https://web.dev/performance', '从代码分割、懒加载、缓存策略、图片优化等多个维度讲解前端性能优化方案。', 'Addy Osmani', 'Web.dev', 6, 950, 1, NOW(), 1);

-- 插入Java后端相关文章
INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('Spring Boot 3.0 新特性解读', 2, 'https://example.com/springboot.jpg', 'https://spring.io/projects/spring-boot', 'Spring Boot 3.0基于Spring Framework 6.0，支持Java 17+，带来AOT编译、Micrometer可观测性等重大更新。', 'Josh Long', 'Spring官方', 1, 2300, 1, NOW(), 0);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('Spring Cloud 微服务架构实战', 2, 'https://example.com/springcloud.jpg', 'https://spring.io/projects/spring-cloud', '详解Spring Cloud Gateway、Nacos、Sentinel、Seata等组件，构建高可用微服务系统。', '翟永超', 'Spring官方', 2, 1900, 1, NOW(), 0);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('Java 并发编程核心原理', 2, 'https://example.com/concurrent.jpg', 'https://docs.oracle.com/javase/tutorial', '深入理解Java内存模型、volatile、synchronized、Lock、线程池等并发编程核心技术。', 'Brian Goetz', 'Oracle', 3, 1650, 1, NOW(), 0);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('JVM 性能调优指南', 2, 'https://example.com/jvm.jpg', 'https://docs.oracle.com/javase', '从GC算法、内存模型、监控工具、调优案例等角度全面讲解JVM性能优化。', '周志明', 'InfoQ', 4, 1400, 1, NOW(), 0);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('MyBatis-Plus 快速上手', 2, 'https://example.com/mybatisplus.jpg', 'https://baomidou.com', 'MyBatis-Plus是MyBatis的增强工具，提供CRUD、分页、代码生成等强大功能，大幅提升开发效率。', '青苗', 'Baomidou', 5, 1200, 1, NOW(), 0);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('Redis 缓存设计与实战', 2, 'https://example.com/redis.jpg', 'https://redis.io', '讲解Redis数据类型、持久化、集群部署、缓存穿透/击穿/雪崩解决方案等核心知识。', '黄健宏', 'Redis官方', 6, 1750, 1, NOW(), 0);

-- 插入Python相关文章
INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('Python 3.12 新特性概览', 2, 'https://example.com/python312.jpg', 'https://docs.python.org', 'Python 3.12带来性能提升、f-string改进、类型注解增强等新特性，让代码更简洁高效。', 'Guido van Rossum', 'Python官方', 1, 2000, 1, NOW(), 2);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('Django 5.0 Web开发实战', 2, 'https://example.com/django.jpg', 'https://www.djangoproject.com', 'Django是Python最流行的Web框架，本文介绍模型、视图、模板、ORM、Admin等核心功能。', 'Adrian Holovaty', 'Django官方', 2, 1600, 1, NOW(), 2);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('Flask 轻量级Web开发指南', 2, 'https://example.com/flask.jpg', 'https://flask.palletsprojects.com', 'Flask是一个轻量级Web框架，灵活易扩展，适合快速开发和小型项目。', 'Armin Ronacher', 'Pallets', 3, 1350, 1, NOW(), 2);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('Python 数据分析与Pandas', 2, 'https://example.com/pandas.jpg', 'https://pandas.pydata.org', 'Pandas是Python数据分析的核心库，提供DataFrame数据结构，支持数据清洗、转换、分析。', 'Wes McKinney', 'Pandas官方', 4, 1850, 1, NOW(), 2);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('机器学习入门：Scikit-learn实战', 2, 'https://example.com/sklearn.jpg', 'https://scikit-learn.org', '使用Scikit-learn进行机器学习：数据预处理、特征工程、模型训练、评估与调优。', 'Andreas Mueller', 'Scikit-learn', 5, 1500, 1, NOW(), 2);

INSERT INTO article (title, type, cover_url, link_url, description, author, source, sort, view_count, status, publish_time, category) VALUES
('Python 异步编程：asyncio详解', 2, 'https://example.com/asyncio.jpg', 'https://docs.python.org/library/asyncio', '深入理解Python异步IO编程：async/await、事件循环、协程、并发执行等核心概念。', 'Luciano Ramalho', 'Python官方', 6, 1100, 1, NOW(), 2);
