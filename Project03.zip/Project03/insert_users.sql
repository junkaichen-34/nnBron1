-- 插入16个学生用户到sys_user表
-- 密码统一使用: $2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO (加密后的'123456')

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('zhangweimin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '张伟民', 'https://example.com/avatar1.jpg', 2, '13800138001', 0, 'zhangweimin@example.com', 1, NOW(), '计算机科学与技术专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('lijiarui', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '李嘉睿', 'https://example.com/avatar2.jpg', 2, '13800138002', 0, 'lijiarui@example.com', 1, NOW(), '软件工程专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('wanghaoran', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '王浩然', 'https://example.com/avatar3.jpg', 2, '13800138003', 0, 'wanghaoran@example.com', 1, NOW(), '信息与计算科学专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('liuyang', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '刘洋', 'https://example.com/avatar4.jpg', 2, '13800138004', 0, 'liuyang@example.com', 1, NOW(), '网络工程专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('chenmingxuan', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '陈明轩', 'https://example.com/avatar5.jpg', 2, '13800138005', 0, 'chenmingxuan@example.com', 1, NOW(), '人工智能专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('yangzihan', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '杨子涵', 'https://example.com/avatar6.jpg', 2, '13800138006', 0, 'yangzihan@example.com', 1, NOW(), '数据科学与大数据技术专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('zhaoxinyue', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '赵欣悦', 'https://example.com/avatar7.jpg', 2, '13800138007', 0, 'zhaoxinyue@example.com', 1, NOW(), '电子商务专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('wuyifan', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '吴逸凡', 'https://example.com/avatar8.jpg', 2, '13800138008', 0, 'wuyifan@example.com', 1, NOW(), '数字媒体技术专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('zhouxiaolin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '周晓琳', 'https://example.com/avatar9.jpg', 2, '13800138009', 0, 'zhouxiaolin@example.com', 1, NOW(), '信息安全专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('xujiayin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '徐佳莹', 'https://example.com/avatar10.jpg', 2, '13800138010', 0, 'xujiayin@example.com', 1, NOW(), '物联网工程专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('sunhaoyu', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '孙浩宇', 'https://example.com/avatar11.jpg', 2, '13800138011', 0, 'sunhaoyu@example.com', 1, NOW(), '通信工程专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('mayuxuan', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '马雨萱', 'https://example.com/avatar12.jpg', 2, '13800138012', 0, 'mayuxuan@example.com', 1, NOW(), '自动化专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('zhuyifan', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '朱一凡', 'https://example.com/avatar13.jpg', 2, '13800138013', 0, 'zhuyifan@example.com', 1, NOW(), '电子信息工程专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('huxiaoming', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '胡晓明', 'https://example.com/avatar14.jpg', 2, '13800138014', 0, 'huxiaoming@example.com', 1, NOW(), '智能科学与技术专业');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('guojiaqi', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '郭佳琪', 'https://example.com/avatar15.jpg', 2, '13800138015', 0, 'guojiaqi@example.com', 1, NOW(), '统计学');

INSERT INTO sys_user (username, password, real_name, avatar, role_type, phone, deleted, email, status, register_time, remark) VALUES
('linyuxin', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iAt6Z5EO', '林雨欣', 'https://example.com/avatar16.jpg', 2, '13800138016', 0, 'linyuxin@example.com', 1, NOW(), '应用数学专业');
